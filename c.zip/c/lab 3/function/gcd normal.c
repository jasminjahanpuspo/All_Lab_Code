#include<stdio.h>
int main()
{
    int gcd,i,min,sum=0,a,b;
    scanf("%d%d",&a,&b);
    if(a<b)
    {
        min=a;
    }
    else
        min=b;
        for(i=1; i<=min; i++)
        {
            if(a%i==0 && b%i==0)
            {
                gcd=i;
            }

        }
        printf("Gcd is %d\n",gcd);
}
