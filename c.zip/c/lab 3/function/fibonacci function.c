#include<stdio.h>
int fib(int n);
int main()
{
    int n;
    scanf("%d",&n);
    fib(n);
}
int fib(int n)
{
    int ne,t1=0,t2=1,i;
    for(i=1; i<=n; i++)
    {
        printf("%d\t",t1);
        ne=t1+t2;
        t1=t2;
        t2=ne;
    }

}
