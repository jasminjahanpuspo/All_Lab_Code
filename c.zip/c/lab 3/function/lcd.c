#include<stdio.h>
int main()
{
    int gcd,i,min,sum=0,a,b;
    scanf("%d%d",&a,&b);
    if(a>b)
    {
        min=a;
    }
    else
        min=b;
        for(i=min; ; i++)
        {
            if(i%a==0 && i%b==0)
            {
                gcd=i;
                break;

            }

        }
        printf("Gcd is %d\n",gcd);
}

