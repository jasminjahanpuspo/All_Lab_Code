#include<stdio.h>
int sum(int a,int b)
{
    int result;
    result=a+b;
    return result;
}
int main()
{
    int r=sum(10,20);
    printf("%d",r);
}
