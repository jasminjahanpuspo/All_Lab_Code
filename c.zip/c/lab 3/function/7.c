#include<stdio.h>
 long int sum(int a,float b)
{
    float r;
    r=a+b;
    long int x=(int)r;
    return x;
}
int main()
{
    int result;
    result=sum(10,20.5);
    printf("%d",result);
}
