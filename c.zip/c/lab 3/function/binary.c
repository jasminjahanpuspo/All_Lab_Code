#include<stdio.h>
int main()
{
    int num,bin;
    scanf("%d",&num);
    bin=bin_con(num);
    printf("%d",bin);
}
int bin_con(int num)
{
    int y;
    if(num==0)
        return 0;
    else
        y=(num%2)+10*bin_con(num/2);
        return y;
}
