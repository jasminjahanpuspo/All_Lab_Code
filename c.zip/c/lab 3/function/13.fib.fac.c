#include<stdio.h>
int main()
{
    int n,t1=1,t2=1,next=0,fact=1,i;
    float sum=0,r;
    scanf("%d",&n);
    for(i=1; i<=n;i++)
   {
       fact=fact*i;
   }
   printf("fact %d\n\n",fact);
   for(i=1; i<=n; i++)
   {
       r=t1/fact;
       sum=sum+r;
       next=t1+t2;
       t1=t2;
       t2=next;

   }
   printf("fibonacci %d\n\n",sum);
   float r;
   r=sum/fact;
   printf("sum %f\n\n",r);
}

