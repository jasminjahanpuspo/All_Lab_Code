#include<stdio.h>
void gcd(int a,int b)
{
    int min=a,gcd,i;
    if(b<a)
        min=b;
    for(i=1; i<=min;i++)
    {
        if(a%i==0 && b%i==0)
        {
            gcd=i;
        }
    }
    printf(" gcd is %d\n",gcd);
}
int main()
{
    int a,b,i;
    for(i=0; i<5; i++)
    {
        scanf("%d%d",&a,&b);
        gcd(a,b);
    }
}
