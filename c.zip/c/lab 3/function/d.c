#include<stdio.h>
int main()
{
    int num,i,n,j,l,k;
    scanf("%d",num);
    for(i=1; i<=num; i++)
    {
        if(num%i==0)
        {
            printf("Facor %d",i);
        }
    }
}
    for(j=1; j<=i; j++)
    {
        l=0;
        for(k=1;k<=i;k++)
        {
            if(j%k==0)
            {
                l++;
            }
        }
        if(l==2)
        {
            printf("prime fact %d",j);
        }
    }
}
