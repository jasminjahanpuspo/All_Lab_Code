#include<stdio.h>
void add(void)
{
    int i,num,lsd,sum=0;
    scanf("%d",&num);
    lsd=num%10;
    while(num>0)
    {
        sum=sum+lsd;
        num=num/10;
        lsd=num%10;
    }
    printf("%d",sum);
}
int main()
{
    add();
}
