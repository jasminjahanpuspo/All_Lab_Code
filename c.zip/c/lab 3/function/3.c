#include<stdio.h>
void products(void)
{
float a,b;
int c;
scanf("%f%f%d",&a,&b,&c);
printf("%f",a*b*c);
}
int main()
{
    products();
}
