#include<stdio.h>
int main()
{
    unsigned int x=-20;
    printf("%d\n",x);
   // int i=017;
    //printf("%d",i);
    //char ch =130;
    //printf("%s",ch);
}
