#include<stdio.h>
void division(int a,int b)
{
    float d;
    if(b==0)
    {
        printf("Arithmetic error.\n");
        return;
    }
    d=(float)a/b;
    printf("Division %.2f",d);
}
int main()
{
    int x,y;
    scanf("%d%d",&x,&y);
    division(x,y);
}
