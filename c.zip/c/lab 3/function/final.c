#include<stdio.h>
struct student{
    int id;
    float gp;
    char ch[10];
};
int main()
{
    struct student ch[10];
    int i;
    for(i=0; i<2; i++)
    {
        fgets(ch,10,stdin);
    }
    for(i=0; i<2; i++)
    {
        fputs(ch,stdout);
    }


}
