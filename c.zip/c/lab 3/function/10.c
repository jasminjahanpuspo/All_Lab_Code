#include<stdio.h>
float sum(int ,float,int);
int main()
{
    float x;
    x=sum(10,20.5,20);
    printf("%f",x);
}
float sum(int a,float b,int c)
{
    return a+b+c;
}
