#include<stdio.h>
int differ(int,int);
int differ(int a,int b)
{
        int r;
        if(a>b)
        {
            r=a-b;
        }
        else
        {
            r=b-a;
        }

        return r;
}

    int main()
    {
        int x,y;
        scanf("%d%d",&x,&y);
        int result=differ(x,y);
        printf("%d",result);
    }

