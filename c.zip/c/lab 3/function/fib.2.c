#include<stdio.h>
int main()
{
    int next,t1=0,t2=1,ans,n,i,sum=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        printf("%d\t",t1);
        sum=sum+t1;
        next=t1+t2;
        t1=t2;
        t2=next;
    }
    printf("\n%d\n",sum);
    int fact=1,m;
    scanf("%d",&m);
    for(i=1; i<=m; i++)
    {
        fact=fact*i;
    }
    printf("\n%d",fact);
}
