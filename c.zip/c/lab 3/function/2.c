#include<stdio.h>
float products(float,int,float);
float products(float a,int b,float c)

{
    return a*b*c;
}
int main()
{
    float x,y;
    int z;
    scanf("%f%d%f",&x,&z,&y);
    float result=products(x,z,y);
    printf("%f",result);

}
