#include<stdio.h>
int add(int,int,int,int,int);
int add(int a,int b,int c,int d,int e)
{
    int r;
    r=a+b+c+d+e;
    return r;
}
int main()
{
    int a,b,c,d,e;
    scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
    int sum=add(a,b,c,d,e);
    printf("sum is %d\n\n",sum);
    float avg=sum/5;
    printf("the average %.2f\n\n",avg);
}

