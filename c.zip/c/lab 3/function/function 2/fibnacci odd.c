#include<stdio.h>
int main()
{
    int i,n,next,t1=0,t2=1;
    for(i=1; i<=10; i=i+1)
    {
        if(%2==1){
        printf("%d\t",t1);
        next=t1+t2;
        t1=t2;
        t2=next;
        }
    }
}
