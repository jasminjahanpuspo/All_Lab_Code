#include<stdio.h>
float div(int a,int b);
int main()
{
    int a,b;
    float di;
    scanf("%d%d",&a,&b);
    di=div(a,b);
    printf("%f",di);
}
float div(int a,int b)
{
    float d;
    if(b==0)
    {
        printf("erroe");
        return 0 ;
    }
    else
    {
        d=(float)a/b;
    }
    return d;
}
