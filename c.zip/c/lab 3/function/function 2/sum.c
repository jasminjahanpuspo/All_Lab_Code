#include<stdio.h>
int sum(int a,int b)
{
    int re;
    re=a+b;
    return re;
}
int main()
{
    int a,b,re;
    scanf("%d%d",&a,&b);
    re=sum(a,b);
    printf("%d",re);
}
