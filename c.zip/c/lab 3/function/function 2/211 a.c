#include<stdio.h>
int add(int a,int b,int c,int d,int e);
int main()
{
    int a,b,c,d,e,sum=0;
    scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
    sum=add(a,b,c,d,e);
    float avg=(float)sum/5;
    printf("%d\n",sum);
    printf("%f",avg);
}
int add(int a,int b,int c,int d,int e)
{
    int r;
    r=a+b+c+d+e;
    return r;
}


