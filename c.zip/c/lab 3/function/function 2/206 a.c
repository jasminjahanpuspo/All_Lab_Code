#include<stdio.h>
int fact(int a);
int main()
{
    int n,ans;
    scanf("%d",&n);
    ans=fact(n);
    printf("%d",ans);
}
int fact(int a)
{
    int re,fact=1,i;
    for(i=1; i<=a; i++)
    {
        fact=fact*i;
    }
    return fact;
}
