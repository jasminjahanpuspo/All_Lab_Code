#include<stdio.h>
int differ(int ,int);
int main()
{
    int a,b,sub;
    scanf("%d%d",&a,&b);
    sub=differ(a,b);
    printf("%d",sub);
}
int differ(int a,int b)
{
    int r;
    if(a>b)
        r=a-b;
    else
        r=b-a;
    return r;
}
