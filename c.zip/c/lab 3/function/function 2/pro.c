#include<stdio.h>
float product(float a,int b,float c);
int main()
{
    int b;
    float a,c,mult;
    scanf("%f%d%f",&a,&b,&c);
    mult=product(a,b,c);
    printf("%f",mult);
}
float product(float a,int b,float c)
{
    float re;
    re=a*b*c;
    return re;
}
