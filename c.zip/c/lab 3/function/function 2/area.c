#include<stdio.h>
void area();
int main()
{
    area();
}
void area( )
{
    float s,a,b,c,areaa;
    scanf("%f%f%f",&a,&b,&c);
    s=(a+b+c)/2;
    areaa=sqrt(s*(s-a)*(s-b)*(s-c));
    printf("%f",areaa);

}
