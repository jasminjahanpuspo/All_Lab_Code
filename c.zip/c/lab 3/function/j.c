#include<stdio.h>
void add(void)
{
    float a,b,c,s,area;
    scanf("%f%f%f",&a,&b,&c);
    s=(a+b+c)/2;
    area=sqrt(s*(s-a)*(s-b)*(s-c));
    printf("\n\nthe area of triangle %.2f\n\n",area);
}
int main()
{
    add();
}
