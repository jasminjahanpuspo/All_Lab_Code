#include<stdio.h>
float sum(int ,int );
float sum(int a,int b)
{
    return a+b;
}
int main()
{
    float x;
    int p=10,q=20;
    x=sum(p,q);
    printf("%f",x);
}
