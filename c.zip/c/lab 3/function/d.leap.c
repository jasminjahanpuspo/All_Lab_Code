#include<stdio.h>
void leap(void)
{
    int year;
    int rem4,rem100,rem400;
    printf("enter an year ");
    scanf("%d",&year);
    rem4=year%4;
    rem100=year%100;
    rem400=year%400;
    if((rem4==0 && rem100 ==1))
    {
        printf("%d is leap year\n",year);
    }
    else if(rem400==0)
    {
        printf("%d is leap year\n",year);
    }
    else
    {
        printf("%d is not leap year\n",year);
    }
}
int main()
{
    leap();
}
