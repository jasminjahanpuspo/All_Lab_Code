#include<stdio.h>
int power(int,int);
int power(int x,int y)
{
    int result=1;
    while(y>0)
    {
        result=result*x;
        --y;
    }
    return result;
}
int main()
{
    int a,b,result_2;
    scanf("%d%d",&a,&b);
    result_2=power(a,b);
    printf("%d",result_2);
}
