#include<stdio.h>
int main()
{
    int n,i,fact=1,next,t1=0,t2=1;
    float ans=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        fact=fact*i;
       ans=ans+(float)t1/fact;
        next=t1+t2;
        t1=t2;
        t2=next;
    }
    printf("%d\n",fact);
    printf("%f",ans);
}
