#include<stdio.h>
int main()
{
    char c[]="hellow";
    char ch[50];
    strcpy(ch,c);
    fputs(ch,stdout);
    printf("\n%d",sizeof(c));
}
