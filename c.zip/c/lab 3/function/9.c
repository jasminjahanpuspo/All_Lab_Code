#include<stdio.h>
int sum(int a ,int b);
int main()
{
    int x;
    x=sum(10,20);
    printf("%d",x);
}
int sum(int a,int b)
{
   return a+b;
}
