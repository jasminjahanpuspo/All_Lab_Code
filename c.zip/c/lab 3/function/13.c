#include<stdio.h>
void sum()
{
    int r,a,b;
    scanf("%d%d",&a,&b);
    r=a+b;
    printf("%d",r);
}
int main()
{
    sum();
}
