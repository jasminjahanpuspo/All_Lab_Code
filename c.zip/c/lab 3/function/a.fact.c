#include<stdio.h>
int fact(int);
int fact(int x)
{
    int i,fact=1;
    for(i=1; i<=x;i++)
    {
        fact=fact*i;
    }
    return fact;
}
int main()
{
    int x,y;
    scanf("%d",&x);
    y=fact(x);
    printf("%d",y);
}
