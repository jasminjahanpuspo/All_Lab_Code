#include<stdio.h>
float division(char a,char b)
{
    float d;
    if(b==0)
    {
        return 256;
    }
    d=(float)a/b;
    return d;
}
int main()
{
    int x,y;
    scanf("%d%d",&x,&y);
    float p=division(x,y);
    if(p==256)
        printf("Arithmetic error.\n");
    else
        printf("Division %.2f",p);
}
