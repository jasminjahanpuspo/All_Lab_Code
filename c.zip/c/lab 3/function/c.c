#include<stdio.h>
int add(int);
int add(int num)
{
    int lsd,sum=0;
    lsd=num%10;
    while(num>0)
    {
        sum=sum+lsd;
        num=num/10;
        lsd=num%10;
    }
    return sum;
}
int main()
{
    int num,rum;
    scanf("%d",&num);
    rum=add(num);
    printf("%d",rum);
}
