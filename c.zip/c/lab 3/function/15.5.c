#include<stdio.h>
int prime(int a)
{
    int i,flag=0;
    for(i=2;i<a;i++)
    {
        if(a%i==0)
        {
            flag=0;
            break;
        }
    }
    if(i==a)
        flag=1;
    return flag;
}
int main()
{
    int i;
    for(i=2;i<=100;i++)
    {
        if(prime(i))
            printf("%d\t",i);
    }
}
