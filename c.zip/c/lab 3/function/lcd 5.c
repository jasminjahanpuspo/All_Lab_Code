#include<stdio.h>
void lcd(int a,int b)
{
    int min,i,mum;
    if(a>b)
        min=a;
    else
        min=b;
    for(i=min; ; i++)
    {
        if(i%a==0 && i%b==0)
        {
            mum=i;
            break;
        }
    }
     printf("Lcd %d",mum);


}
int main()
{
    int a,b,i;
    for(i=0; i<5; i++)
    {
    scanf("%d%d",&a,&b);
    lcd(a,b);
    }
}
