#include<stdio.h>
int main()
{
    int *p;
    if(p)
    {
        printf("%d",p);
    }
}
