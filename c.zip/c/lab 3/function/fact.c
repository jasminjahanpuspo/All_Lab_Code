#include<stdio.h>
int main()
{
    int n,i,fact=1;
    float sum=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        fact=fact*i;
        sum=sum+(float)i/fact;
    }
    printf("%f",sum);
}
