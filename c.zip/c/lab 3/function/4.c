#include<stdio.h>
float product(void);
float product(void)
{
    float a,b;
    int c;
    printf("Enter 2 float\n");
    scanf("%f%f",&a,&b);
    printf("Enter an int\n");
    scanf("%d",&c);
    return a*b*c;
}
int main()
{
    float result;
    result=product();
    printf("%.2f",result);
}
