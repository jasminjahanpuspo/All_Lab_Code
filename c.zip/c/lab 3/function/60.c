#include<stdio.h>
int main()
{
    int a[3]={10,20,30};
    int *p;
    p=&a[1];
    printf("%d\n",&a[0]);
    printf("%d\n",&a[1]);
    printf("%d\n",&a[2]);
    printf("%d\n",&p[0]);
    printf("%d\n",&p[1]);
    printf("%d\n",&p[2]);
    printf("%d\n",p+1);
    printf("%d\n",++p);
    printf("%d\n",p);
    printf("%d\n",a);
    printf("%d\n",a+1);
    printf("%d\n",a+1);

}

