#include<stdio.h>
int main()
{
    int n,re,bi=0,i=1,va;
    scanf("%d",&n);
    va=n;
    while(n>0)
    {
        re=n%2;
        n=n/2;
        bi=bi+(re*i);
        i=i*10;
    }
    printf("%d",bi);
}
