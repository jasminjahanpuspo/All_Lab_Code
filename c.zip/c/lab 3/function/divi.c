#include<stdio.h>
void div(int a,int b)
{
    float d;
    if(b==0)
    {
        printf("erro");
        return ;
    }
    else
   {

    d=(float)a/b;
    printf("%f",d);
   }
}
int main()
{
    int x,y;
    scanf("%d%d",&x,&y);
    div(x,y);
}
