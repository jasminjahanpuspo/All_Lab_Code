#include<stdio.h>
int pro(float ,int,float);
int main()
{
    int b,ans;
    float a,c;
    scanf("%f%d%f",&a,&b,&c);
    ans=pro(a,b,c);
    printf("%d",ans);
}
int pro(float a,int b,float c)
{
    int x;
    float ans;
    ans=a*b*c;
    x=(int)ans;
    return x;
}
