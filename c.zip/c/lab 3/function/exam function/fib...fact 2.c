#include<stdio.h>
float series(int n);
int main()
{
    int n;
    float ans;
    scanf("%d",&n);
    ans=series(n);
    printf("%f",ans);
}
float series(int n)
{
    int i,next,t1=0,t2=1,fact=1;
    float sum=0;
    for(i=1;i<=n; i++)
    {
        if(t1==0)
        {
            sum=sum+((float)t1/1);
        }
        fact=fact*i;
        sum=sum+(float)t1/fact;
        next=t1+t2;
        t1=t2;
        t2=next;
    }
    return sum;

}

