#include<stdio.h>
int avg(int,int,int,int,int);
int main()
{
    int a,b,c,d,e,sum=0;
    float av;
    scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
    sum=avg(a,b,c,d,e);
    av=(float)sum/5;
    printf("%d\navg%.2f",sum,av);
}
int avg(int a,int b,int c,int d,int e)
{
    int re;
    re=a+b+c+d+e;
    return re;
}
