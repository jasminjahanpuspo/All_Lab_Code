#include<stdio.h>
int gcd(int,int);
int main()
{
    int a,b,i,ans;
    for(i=0; i<5;i++)
    {
        scanf("%d%d",&a,&b);
        ans=gcd(a,b);
        printf("%d",ans);
    }


}
int gcd(int a,int b)
{
    int i,min=a,gcd;
    if(a>b)
        min=b;
    for(i=1; i<=min; i++)
    {
        if(a%i==0 && b%i==0)
        {
            gcd=i;
        }
    }
      return gcd;

}
