#include<stdio.h>
void swap(int *a,int *b);
int main()
{
    int a=10, b=20;
    swap(&a,&b);
    printf("%d=a,%d=b",a,b);
}
void swap(int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}
