#include<stdio.h>
int power(int a,int b);
int main()
{
    int a,b,ans;
    scanf("%d%d",&a,&b);
    ans=power(a,b);
    printf("%d",ans);

}
int power(int a,int b)
{
    int re=1;
    while(b>0)
    {
        re=re*a;
        b--;
    }
    return re;
}
