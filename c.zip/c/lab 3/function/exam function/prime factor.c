#include<stdio.h>
int main()
{
    int i,n;
    scanf("%d",&n);
    for(i=2; x>1; i++)
    {
        if(n%i==0)
        {
            printf("%d\t",i);
            n=n/i;
        }
    }

}
