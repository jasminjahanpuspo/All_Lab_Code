#include<stdio.h>
void leap(int year);
int main()
{
    int year;
    scanf("%d",&year);
    leap(year);
}
void leap(int year)
{
    int rem4,rem100,rem400;
    rem4=year%4;
    rem100=year%100;
    rem400=year%400;
    if(rem4==0 && rem100!=0)
    {
        printf("Leap");
    }
    else if(rem400==0)
    {
        printf("leap");
    }
    else
        printf("not");
}
