#include<stdio.h>
int prime(int a);
int main()
{
    int a;
    while(1)
    {
        scanf("%d",&a);
        if(a==0)
            break;
    }
    if(1==prime(a))
        printf("prime");
    else
        printf("not");
}
int prime(int a)
{
    int i;
    if(a<2)
        return 0;
    for(i=2; i<a; i++)
    {
        if(a%i==0)
        {
            return 0;
        }
    }
    return 1;
}
