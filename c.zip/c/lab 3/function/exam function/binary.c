#include<stdio.h>
int binary(int n);
int main()
{
    int n,ans;
    scanf("%d",&n);
    ans=binary(n);
    printf("%d",ans);
}
int binary(int n)
{
    int bi=0,i=1,re;
    while(n>0)
    {
        re=n%2;
        n=n/2;
        bi=bi+(re*i);
        i=i*10;
    }
    return bi;
}
