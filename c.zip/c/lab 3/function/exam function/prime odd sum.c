#include<stdio.h>
int prime(int a);
int main()
{
    int i,sum=0;
    for(i=2; i<=100; i++)
    {
        if(prime(i))
        if(i%2==1){
            printf("%d\t",i);
            sum+=i;
        }
    }
    printf("\n\n%d",sum);
}
int prime(int a)
{
    int i,flag;
    for(i=2; i<a; i++)
    {
        if(a%i==0)
        {
            flag=0;
            break;
        }
    }
    if(i==a)
    {
        flag=1;
    }
    return flag;
}


