#include<stdio.h>
int sum(int a);
int main()
{
    int a,re=0;
    scanf("%d",&a);
    re=sum(a);
    printf("%d",re);
}
int sum(int a)
{
    int lsd,sum=0;
    lsd=a%10;
    while(a>0)
    {
        sum=sum+lsd;
        a=a/10;
        lsd=a%10;
    }
    return sum;

}
