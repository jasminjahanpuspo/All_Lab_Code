#include<stdio.h>
int lcd(int a,int b);
int main()
{
    int a,b,i,ans;
    for(i=0; i<5; i++)
    {
        scanf("%d%d",&a,&b);
        ans=lcd(a,b);
        printf("%d",ans);
    }
}
int lcd(int a,int b)
{
    int min=a,i,ans;
    if(b>a)
        min=b;
    for(i=min; ;i++)
    {
        if(i%a==0 && i%b==0)
        {
            ans=i;
            break;
        }
    }
    return ans;
}
