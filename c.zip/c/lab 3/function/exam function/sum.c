#include<stdio.h>
int sum(int a,int b);
int main()
{
    int a,b,add=0;
    scanf("%d%d",&a,&b);
    add=sum(a,b);
    printf("%d",add);
}
int sum(int a,int b)
{
    int r=a+b;
    return r;
}
