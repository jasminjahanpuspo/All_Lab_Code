#include<stdio.h>
int differ(int a,int b);
int main()
{
    int a,b,ans=0;
    scanf("%d%d",&a,&b);
    ans=differ(a,b);
    printf("%d",ans);
}
int differ(int a,int b)
{
    int ans;
    if(a>b)
        ans=a-b;
    else
        ans=-(a-b);
    return ans;
}
