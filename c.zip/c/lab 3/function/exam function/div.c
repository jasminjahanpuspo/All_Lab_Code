#include<stdio.h>
float  div(int a,int b);
int main()
{
    int a,b;
    float ans;
    scanf("%D%d",&a,&b);
    ans=div(a,b);
    printf("%f",ans);
}
float div(int a,int b)
{
    float d;
    if(b==0){
        printf("error");
        return 0;
    }
    else
    {
        d=(float)a/b;
    }
    return d;
}
