#include<stdio.h>
int prime(int a);
int main()
{
    int i;
    for(i=2; i<=100; i++)
    {
        if(prime(i))
            printf("%d\t",i);
    }
}
int prime(int a)
{
    int i,flag;
    for(i=2; i<a; i++)
    {
        if(a%i==0)
        {
            flag=0;
            break;
        }
    }
    if(i==a)
    {
        flag=1;
    }
    return flag;
}

