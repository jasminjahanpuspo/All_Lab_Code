#include<stdio.h>
float area (void);
int main()
{
    float ans;
    ans=area();
    printf("%f",ans);
}
float area(void)
{
    int a,b,c;
    float s,ans;
    scanf("%d%d%d",&a,&b,&c);
    s=(a+b+c)/2;
    ans=sqrt(s*(s-a)*(s-b)*(s-c));
    return ans;
}

