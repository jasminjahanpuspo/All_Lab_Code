#include<stdio.h>
int main()
{
    int a[3]={10,20,30};
    printf("%d\n",&a[0]);
    printf("%d\n",&a[1]);
    printf("%d\n",&a[2]);
    printf("%d\n",a);
    printf("%d\n",a+1);
    printf("%d\n",*(a+1));

}


