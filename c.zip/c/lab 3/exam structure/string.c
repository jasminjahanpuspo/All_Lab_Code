#include<stdio.h>
struct pro
{
    int id;
    float price;
    char pp[5];
}p;
int main()
{
    scanf("%d%f",&p.id,&p.price);
    fgets(p.pp,5,stdin);
    printf("Id %d\tprice%.2f\t",p.id,p.price);
    fputs(p.pp,stdout);

}
