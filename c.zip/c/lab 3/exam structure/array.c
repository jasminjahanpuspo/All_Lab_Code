#include<stdio.h>
struct pro
{
    int id;
    float price;
};
int main()
{
    struct pro p[2];
    int i;
    for(i=0; i<2; i++)
    {
        scanf("%d",&p[i].id);
        scanf("%f",&p[i].price);
    }
    for(i=0; i<2; i++)
    {
        printf("product %d\nid %d\tprice%.2f\n\n",i+1,p[i].id,p[i].price);
    }
}

