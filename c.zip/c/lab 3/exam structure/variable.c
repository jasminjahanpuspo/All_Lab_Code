#include<stdio.h>
struct pro
{
    int id;
    float price;
}p,o;
int main()
{
    p.id=1;
    p.price=56.3;
    o.id=7;
    o.price=66.9;
    printf("p\nid=%d\tprice=%.2f\n\no\nid=%d\tprice=%.2f\n\n",p.id,p.price,o.id,o.price);
}
