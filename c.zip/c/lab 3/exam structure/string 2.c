#include<stdio.h>
struct student
{
    int id;
    char name[10];
    float cgpa;
}p,o;
int main()
{
    p.id=10;
    p.cgpa=4.65;
    fgets(p.name,10,stdin);
    o.id=12;
    o.cgpa=5.88;
    fgets(o.name,10,stdin);
    if(p.cgpa>o.cgpa){
    printf("Id %d\tprice%.2f\t",p.id,p.cgpa);
    fputs(p.name,stdout);
    }
    else{

    printf("Id %d\tprice%.2f\t",o.id,o.cgpa);
    fputs(o.name,stdout);

    }

}
