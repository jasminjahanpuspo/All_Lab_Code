#include<stdio.h>
struct pro
{
    int id;
    float price;
}p,*o;
int main()
{
    o=&p;
    scanf("%d%f",&p.id,&p.price);
    printf("id %d\tprice%f",p.id,p.price);
    printf("%d==id\t%.2f==price",o->id,o->price);
}

