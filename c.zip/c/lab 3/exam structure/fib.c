#include<stdio.h>
void fib(int);
int main()
{
    int n,ans;
    scanf("%d",&n);
    fib(n);
}
void fib(int n)
{
    int next,t1=0,t2=1,sum=0;
    int i;
    for(i=1; i<=n ;i++)
    {
        if(i%2==1){
        printf("%d\t",i);
        sum=sum+t1;
        next=t1+t2;
        t1=t2;
        t2=next;
        }
       // return t1;
    }
    printf("%d",sum);
}
