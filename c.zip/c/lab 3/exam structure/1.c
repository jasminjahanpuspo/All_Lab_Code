#include<stdio.h>
struct pro
{
    int id;
    float pri;
};
int main()
{
   struct pro p[2];
   int i;
   for(i=0; i<2; i++)
   {
      scanf("%d",&p[i].id);
      scanf("%f",&p[i].pri);
   }
   for(i=0; i<2; i++)
   {
       printf("%d-- id%d\tprice %f\n",i+1,p[i].id,p[i].pri);
   }
}
