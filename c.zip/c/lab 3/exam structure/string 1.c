#include<stdio.h>
struct pro
{
    int id;
    float price;
    char p[10];
};
int main()
{
    struct pro pp={1,10.5,"alu"};
    fputs(pp.p,stdout);
    printf("\tid %d\tprice %.2f\n\n",pp.id,pp.price);
}
