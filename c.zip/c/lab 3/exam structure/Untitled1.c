#include<stdio.h>
struct pro
{
    int id;
    float price;
};
int main()
{
    struct pro p1;
    struct pro p2;
    p1.id=1;
    p1.price=40.5;
    p2.id=2;
    p2.price=50.5;
    printf("%p1.id=%d\tp1.price %f",p1.id,p1.price);
}
