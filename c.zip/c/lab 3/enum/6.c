#include<stdio.h>
enum day{sat,sun,mon,tues
};
int main()
{
    char *day[]={"sat","sun","mon","tues"};
    enum day today=sun;
    enum day nextday=today+1;
    printf("%s",day[today]);
    printf("%s",nextday);
}
