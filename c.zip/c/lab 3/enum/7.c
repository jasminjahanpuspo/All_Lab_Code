#include<stdio.h>
enum day{sat=3,sun,mon,tues,wed,thrus,fri};
int main()
{
    enum day today=sat;
    enum day nextday=mon+1;
    printf("%d",nextday);
}
