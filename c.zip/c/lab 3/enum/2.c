#include<stdio.h>
#define pi 3.1416
int main()
{
    int r=10,area;
    area=pi*r*r;
    printf("%f",area);
}
