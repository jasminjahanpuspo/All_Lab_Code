#include<stdio.h>
int main()
{
    char *day[]={"sat","sun"};
    int today=3;
    int i;
    printf("%s",day[i+1]);
}
