#include<stdio.h>
enum day{
    sat,sun
};
int main()
{
    enum day today=sun;
    printf("%d",today);
}
