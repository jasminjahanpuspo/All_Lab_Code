#include<stdio.h>
#define PI 3.1416
int main()
{
    int r=10,area;
    float p=3.14;
    //PI=10;
    area=PI*r*r;
    printf("%d",area);
}
