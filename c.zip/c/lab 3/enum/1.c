#include<stdio.h>
int main()
{
    int r=10;
    const float p=3.1416;
    p=10;
    float area=p*r*r;
    printf("%f",area);
}
