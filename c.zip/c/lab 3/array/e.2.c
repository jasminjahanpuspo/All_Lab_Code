#include<stdio.h>
int main()
{
    int n[3],sum=0,i,a;
    printf("How many numbers?\n\n");
    scanf("%d",&a);
    for(i=0; i<=3; i++)
    {
        scanf("%d",&n[i]);
        sum=sum+n[i];
    }
    printf("The sum is %d\n\n",sum);
    for(i=0; i<=3; i++)
    {
        printf("address of  number %d is %d.\n\n",n[i],&n[i]);
    }
}
