#include<bits/stdc++.h>
using namespace std;

int main()
{
    char A[1000000];
    char B[1000000];
    gets(A);
    gets(B);
    if (!strcmp(A, B))
    {
        cout<<"-1";
    }
    else
    {
        if (strlen(A)>strlen(B))
        {
            printf("%d",strlen(A));
        }
        else
        {
            printf("%d",strlen(B));
        }
    }
}

