#include<stdio.h>
enum day{saturday,sunday,monday,tuesday,wednesday,thusday,friday};
char* day[]={"Saturday","Sunday","Monday"};
int main()
{
    enum day today=saturday;
    printf("%d\n",today+2);
    printf("%s\n",day [today+2]);
}
