#include<stdio.h>
struct product
{
    int id;
    float price;
};
int main()
{
    struct product P1;
    struct product *P2;
    P1.id=1;
    P1.price=40.5;
    P2=&P1;
    printf("%d\n",&P1.id);
    printf("%d\n",P2->id);
    printf("%.2f\n",P1.price);
    printf("%.2f\n",P2->price);
}
