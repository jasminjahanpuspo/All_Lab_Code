#include<stdio.h>

int leapyear(int);
int leapyear(int y)
{
    int r;
    if (y%4==0)
    {
        r=y-y;
    }
    else
    {
        r=y;
    }
    return r;
}
int main()
{
    int a;
    scanf("%d",&a);
    int result=leapyear(a);
    if (result==0)
        printf("This is a leap year\n");
    else
        printf("This is not a leap year\n");
}
