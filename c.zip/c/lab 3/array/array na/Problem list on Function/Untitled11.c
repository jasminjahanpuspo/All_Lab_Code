#include<stdio.h>
int main()
{
    if (sizeof(int)>-1)
        printf("%d\n",1);
    else
        printf("%d\n",0);
}
