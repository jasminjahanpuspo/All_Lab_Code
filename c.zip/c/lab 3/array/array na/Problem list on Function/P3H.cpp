#include<bits/stdc++.h>
using namespace std;
int main()
{
    system("COLOR E0");
    char A[1000000];
    char B[1000000];
    gets(A);
    gets(B);
    if (!strcmp(A, B))
    {
        cout<<"-1";
    }
    else
    {
        if (strlen(A)>strlen(B))
        {
            cout<<strlen(A);
        }
        else
        {
            cout<<strlen(B);
        }
    }
}

