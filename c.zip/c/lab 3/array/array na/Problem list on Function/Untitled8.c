#include<stdio.h>
int main()
{
    int a=0x56,i,j,k,p;
    printf("\n%d\n",a);
    int arr[2][2][2][3];
    int size=sizeof (arr[0][0][0])/sizeof (arr[0][0][0][0]);printf("%d",size);

    for (i=0;i<2;i++)
        for (j=0;j<2;j++)
            for (p=0;p<2;p++)
                for (k=0;k<3;k++)
                    scanf("%d",&arr[i][j][p][k]);
    printf("\n\n");


    for (i=0;i<2;i++)
    {
        for (j=0;j<2;j++)
        {
            for (p=0;p<2;p++)
            {
                for (k=0;k<3;k++)
                {
                    printf("%d ",arr[i][j][p][k]);
                }
                printf("\n");
            }
            printf("\n");
        }

        printf("\n");
    }
}
