#include<stdio.h>
#include<math.h>

int power(int, int);
int power(int a, int b)
{
    int r;
        r=powl(b,a);
    return r;
}
int main()
{
    int x,y;
    scanf("%d%d",&x,&y);
    int result=power(x,y);
    printf("\npower: %d\n",result);
}
