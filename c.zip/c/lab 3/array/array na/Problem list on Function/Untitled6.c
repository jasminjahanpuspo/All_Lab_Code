#include<stdio.h>
struct product
{
    int id;
    char pName[35];
    float price;
}P1,P2[10],*P3;
int main()
{
    //struct product P1;
    P1.id=1;
    fgets(P1.pName,35,stdin);
    while (getchar()!='\n');
    P1.price=40.5;
    printf("ID:%d,Name:%s,price:%f\n",P1.id,P1.pName,P1.price);

}
