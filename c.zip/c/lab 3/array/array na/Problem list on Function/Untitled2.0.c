#include<stdio.h>
#define PI 3.1416
int main()
{
    int r=10;
    float area=PI*r*r;
    printf ("%f\n",area);
}
