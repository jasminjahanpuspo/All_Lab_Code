#include<stdio.h>

struct product
{
    int id;
    float price;
};
int main()
{
    struct product P[2];
    struct product *P1[2];

    int i;
    for (i=0;i<2;i++)
    {

        printf("Enter ID of product %d:",i+1);
        scanf("%d",&P[i].id);
        printf("Enter Price of product %d:",i+1);
        scanf("%f",&P[i].price);
    }
    for (i=0;i<2;i++)
    {
        P1[i]=&P[i];
        printf("\n\nProduct %d ID:%d\n",i+1,P1[i]->id);
        printf("Product %d Price:%.2f\n\n",i+1,P1[i]->price);
    }
}
