#include<stdio.h>
#include<conio.h>

/*void swap (int a, int b)
{
    int temp;
    temp=a;
    a=b;
    b=temp;
}
void main()
{
    int x=10,y=20;
    swap (x, y);
    printf("%d  %d\n",x,y);
}*/

void swap(int a, int b)
{
 int temp;
 temp=a;
 a=b;
 b=temp;
}

void main()
{
 int a=100, b=200;
 swap(a, b);  // passing value to function
 printf("\nValue of a: %d",a);
 printf("\nValue of b: %d",b);
 getch();
}
