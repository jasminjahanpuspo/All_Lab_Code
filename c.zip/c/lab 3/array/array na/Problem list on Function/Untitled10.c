#include<stdio.h>
enum size {S,M=3,L,XL=0,XXL};
int main()
{
    enum size shirt =XXL;
    printf("%d\n",shirt);
}
