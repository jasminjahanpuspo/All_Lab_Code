#include<stdio.h>

int factorial (int);
int factorial (int n)
{
    int r;
    if (n>=1)
        r=n*factorial(n-1);
    else
        r=1;
    return r;
}
int main()
{
    int x;
    scanf("%d",&x);
    int result=factorial(x);
    printf("%d\n",result);
}
