#include<stdio.h>
int main()
{
    char ch,c;
    ch=getchar();
    getchar();
    c=getchar();
    getchar();
    putchar('\n');
    putchar(ch);
    putchar(' ');
    putchar(c);
    putchar('\n');
}
