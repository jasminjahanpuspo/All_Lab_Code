//We are printing a.
#include<stdio.h>
int main()
{
    /*WE ARE
    TESING SOME
    COLOR CODE*/
    system("COLOR");
    int a,n;
    for (a=0;a<=9;a++)
    {
        scanf("%d",&n);
        printf("%d\a\a\n\a\a",a++);
    }
    return 0;
}
