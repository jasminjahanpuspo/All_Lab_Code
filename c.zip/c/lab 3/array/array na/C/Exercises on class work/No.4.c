#include<stdio.h>
int main()
{
    printf("University.\r\n");
    printf("North");
    printf("Hi");
}
