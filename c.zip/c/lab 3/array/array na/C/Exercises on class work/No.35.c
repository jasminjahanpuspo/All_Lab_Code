#include<stdio.h>
int main()
{
    int i,j;
    for (i=1;i<=6;i++)
    {
        for (j=1;j<=i;j++)
        {
            if (i%2==1)
            {
                printf("*");
                break;
            }
            else
            {
                if (j==4)
                    continue;
                else if (j==i && i>2)
                    continue;
                else
                    printf("*");
            }
        }
        printf("\n");
    }
}
