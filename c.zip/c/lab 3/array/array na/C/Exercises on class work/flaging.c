#include<stdio.h>
int main()
{
    int i,j,flag=0;
    for (i=0;i<3 && !flag;i++)
    {
        for (j=0;j<10;j++)
        {
            printf("* ");
            if(j==2)
            {
                flag=1;
                break;
            }
        }
        printf("\n");
    }
}
