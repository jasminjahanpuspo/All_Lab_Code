#include<stdio.h>
int main()
{
    int i,j;
    for (i=0;i<3;i++)
    {
        for (j=1;j<=3;j++)
        {
            printf("%d",j);
        }
        printf("\n");
    }
}
