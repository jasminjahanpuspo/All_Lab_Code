#include<stdio.h>
int main()
{
    int i,j;
    int a[2][3],b[2][3];

    //Taking input
    printf("Give the first matrix:\n");
    for (i=0;i<2;i++)
        for (j=0;j<3;j++)
            scanf("%d",&a[i][j]);

    printf("Give the second matrix:\n");
    for (i=0;i<2;i++)
    {
        for (j=0;j<3;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }

    //Printing output
    printf("\nThe matrix is:\n");
    for (i=0;i<2;i++)
    {
        for (j=0;j<3;j++)
            printf("%d\t",a[i][j]+b[i][j]);
        printf("\n");
    }
}
