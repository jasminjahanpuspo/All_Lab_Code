#include<stdio.h>
int main()
{
    int i,j,k;
    int a[3][2],b[2][3],result[3][3];

    printf("Enter the first matrix:\n");
    for (i=0;i<3;i++)
        for (k=0;k<2;k++)
            scanf("%d",&a[i][k]);

    printf("Enter the first matrix:\n");
    for (k=0;k<2;k++)
        for (j=0;j<3;j++)
        scanf("%d",&b[k][j]);

    printf("The matrix is:\n");
    for (i=0;i<3;i++)
    {

        for (j=0;j<3;j++)
        {
             result[i][j]=0;
             for (k=0;k<2;k++)
                result[i][j]=result[i][j]+a[i][k]*b[k][j];
             printf("%d ",result[i][j]);
        }
        printf("\n");
    }
}
