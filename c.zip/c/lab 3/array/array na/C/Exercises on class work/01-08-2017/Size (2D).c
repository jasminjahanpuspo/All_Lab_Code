#include<stdio.h>
int main()
{
    //int row=sizeof(a)/sizeof(a[0]);
    //int col=sizeof(a[0])/sizeof(a[0][0]);

    int a[2][3]={{1,2,3},{4,5,6}};
    int i,j;
    //Taking input

    for (i=0;i<2;i++)
    {
        for (j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    //Printing output
    printf("\nThe matix is:\n");

    for (j=0;j<3;j++)
        printf("%d\t",a[i][j]);
    printf("\n");
}
