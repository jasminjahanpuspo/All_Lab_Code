#include<stdio.h>
int main()
{
    int marks=80;
    switch(marks)
    {
        case 80:
            printf("A+");
            break;
        case 70:
            printf("A");
            break;
        default:
            printf("F");
            break;
    }
}
