#include<stdio.h>
#include<conio.h>
int main()
{
  while(getch () != 27)
        printf("\a");
    return 0;
}
