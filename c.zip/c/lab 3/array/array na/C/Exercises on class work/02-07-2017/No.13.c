#include<stdio.h>
int main()
{
    int num,lsd,sum=0;
    printf("Enter the number:");
    scanf("%d",&num);
    lsd=num%10;
    while (num>0)
    {
        sum=sum+lsd;
        num=num/10;
        lsd=num%10;
    }
    printf("The sum is: %d\n",sum);
}
