#include<stdio.h>
int main()
{
    int n,i,x=1;
    float sum=0;
    printf("Enter N=");
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        x=x*3;
        if (i%2==1)
        {
            sum=sum+1.0/x;
        }
        else
        {
            sum=sum-1.0/x;
        }
    }
    printf("The sum is:%f\n",sum);
}
