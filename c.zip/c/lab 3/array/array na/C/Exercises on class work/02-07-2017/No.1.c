//Find the square of 1 to n.
#include<stdio.h>
int main()
{
    int i,n;
    printf("Enter a number:");
    scanf("%d",&n);
    for (i=1;i<=n;i=i+1)
    {
        printf("%d = %d\n",i,i*i);
    }
}
