#include<stdio.h>
int main()
{
    int i,n;
    float sum=0;
    printf("N=");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+1.0/(i*i);
    }
    printf("The sum=%f\n",sum);
}
