#include<stdio.h>
int main()
{
    int i,n,x=0;
    float sum=0;
    printf("N=");
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        if (i==1)
        {
            sum=sum+(1.0/i);
        }
        else
        {
            x=x+2;
            sum=sum+((float)x/i);
        }
    }
    printf("The sum is:%f",sum);
}
