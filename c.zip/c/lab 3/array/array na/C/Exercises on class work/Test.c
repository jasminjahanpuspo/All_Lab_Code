#include<stdio.h>
int main()
{
    int x=20;
    if(x>=20)
    {
        printf("%.2f\n",x%2+2<5>-5);
    }
}
