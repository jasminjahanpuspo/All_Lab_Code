#include<stdio.h>
int main()
{
    printf("The sum of %d and %d is %d\n",10,20,30);
    printf("%d+%d=%d\n",10,20,30);
    printf("%f+%d=%f\n",10.5,20,30.5);
    printf("%f+%d=%d\bGARBAGE\n\n",10.5,20,30.5);
    printf("%c\n",'a');
    printf("%c%c\n",'H','i');
    printf("%c%c%c\n",'H','i','10','20');
    printf("My name is:%s\n","Saadat");
}
