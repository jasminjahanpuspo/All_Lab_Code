#include<stdio.h>
int main()
{
    system("COLOR 3D");
    printf("We\'re printing: # %% & * - + =,    and    (){}[] >< |\?\n");
}
