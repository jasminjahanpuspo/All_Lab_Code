#include<stdio.h>
#include<string.h>
int main()
{
    char ch1[]="Heee";
    char ch2[]="hEEE";
    //strcmp(ch1,ch2);
    printf("%d\n",strcmp(ch2,ch1));
}
