#include<stdio.h>
int main()
{
    system("COLOR 0A");
    char base;
    int savings,PriceOfGold,PriceOfSilver;
    float ZaakahAmount,NisaabGold,NisaabSilver;
    printf("                                    <<<BISMILLAHIR RAHMANIR RAHIM>>>\n\n");
    printf("Enter your base do you like to pay your Zaakah (for gold press 'g', for silver press 's'):");
    scanf("%c",&base);
    printf("Enter your total savings:");
    scanf("%d",&savings);
    if (base=='g' || base=='s')
    {
         if (base=='g')
         {
             printf("Enter current pure gold price (per grams in tk):");
             scanf("%f",&PriceOfGold);
             NisaabGold=PriceOfGold*85;
             if (NisaabGold<savings)
             {
                 printf("You are not eligible for Zakaah base on gold.\n");
             }
             else
             {
                 ZaakahAmount=savings*(2.5/100);
                 printf("Your Zaakah amount is:%.2f tk.\n\n",ZaakahAmount);
             }
         }
         else
         {
             printf("Enter current pure silver price (per grams in tk):");
             scanf("%f",&PriceOfSilver);
             NisaabSilver=PriceOfSilver*595;
             if (NisaabSilver<savings)
             {
                 printf("Your are not eligible for Zaakah base on silver.\n\n");
             }
             else
             {
                 ZaakahAmount=savings*(2.5/100);
                 printf("Your Zaakah amount is:%.2f tk.\n\n",ZaakahAmount);
             }
         }
    }
    else
    {
        printf("ERROR");
    }
}
