#include<stdio.h>
int main()
{
    printf("Al Mehdi Saadat Chowdury\n");
    printf("Assistant Professor\n");
    printf("Dept. of CSE\n");
    printf("NEUB\n");
    printf("\n");
}
