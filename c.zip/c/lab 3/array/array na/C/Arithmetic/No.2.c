#include<stdio.h>
int main()
{
    float x=10.5,y=10.5;
    int z=(x!=y);
    printf("%d\n",z);
}
