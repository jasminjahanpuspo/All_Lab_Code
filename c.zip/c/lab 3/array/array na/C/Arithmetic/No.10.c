#include<stdio.h>
int main()
{
    int a;
    printf("Enter an integer:\n");
    scanf("%d",&a);
    if(a>10)
    {
        printf("Welcome.\n");
    }
}
