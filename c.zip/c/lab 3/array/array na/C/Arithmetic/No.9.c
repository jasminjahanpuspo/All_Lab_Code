#include<stdio.h>
int main()
{
    int a=255;
    if (a==25)
    {
        printf("%d\n",a);
    }
}
