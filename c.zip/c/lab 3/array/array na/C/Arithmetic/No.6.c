#include<stdio.h>
int main()
{
    int a=1,b=3,c=4,d;
    d=(c>b>a);
    printf("%d",d);
}
