#include<stdio.h>
int main()
{
    int a;
    printf("Enter a integer:\n");
    scanf("%d",&a);
    if(a==5)
    {
        printf("Hi\n");
    }
}
