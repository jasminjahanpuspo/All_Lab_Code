#include<stdio.h>
int main()
{
    int a=5,b=5,c;
    c=(a=b)+9;
    printf("%d",c);
}
