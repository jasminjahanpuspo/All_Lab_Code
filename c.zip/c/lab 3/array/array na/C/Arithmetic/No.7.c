#include<stdio.h>
int main()
{
    //Declare your variables;
    //Assign data;
}
