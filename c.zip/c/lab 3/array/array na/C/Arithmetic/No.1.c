#include<stdio.h>
int main()
{
    int x=10,y=20;
    printf("%d\n",x!=y);
}
