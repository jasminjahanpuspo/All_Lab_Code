#include<stdio.h>
int main()
{
    int a;
    printf("Enter a Number:\n");
    scanf("%d",&a);
    if(a<0)
    {
        a=-a;
    }
    printf("The absolute value is:%d",a);
}
