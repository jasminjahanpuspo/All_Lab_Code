#include<stdio.h>
int main()
{
    /*ways
    roads
    path*/
}
