#include<stdio.h>
int main()
{
    int a=5,b=6,c;
    c=(a=b)+9;
    printf("%d",c);
}
