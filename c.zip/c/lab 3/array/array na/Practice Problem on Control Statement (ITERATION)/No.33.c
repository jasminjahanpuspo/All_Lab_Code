#include<stdio.h>
int main()
{
    int n1,n2,i,j,gcd;
    printf("Enter two numbers:");
    scanf("%d%d",&n1,&n2);
    if (n1<n2)
    {
        for (i=1;i<=n1;i++)
        {
            if (n1%i==0 && n2%i==0)
            {
                gcd=i;
            }
        }
    }
    else
    {
        for (j=1;j<=n2;j++)
        {
            if (n1%j==0 && n2%j==0)
            {
                gcd=j;
            }
        }
    }
    printf("The GCD is: %d\n",gcd);
}
