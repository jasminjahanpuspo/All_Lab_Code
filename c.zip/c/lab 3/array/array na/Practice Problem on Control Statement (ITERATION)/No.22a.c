#include<stdio.h>
int main()
{
    int n,num,dig,i,j,lt,dn,mt;
    scanf("%d",&n);
    num=n;
    lt=n%10;
    for (i=0;i;i++)
    {
        n=n/10;
        if (i==0)
            dig=1;

        else
        {
            for (j=0;j;j++)
            {
                dig=dig*10;
            }
        }
        if (n==0)
            break;
    }
    mt=num/dig;
    printf("Least=%d, Most= %d\n",lt,mt);
}
