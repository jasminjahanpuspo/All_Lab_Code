#include<stdio.h>
int main()
{
    int i,n1,n2,result=1;
    printf("Enter two integers:");
    scanf("%d%d",&n1,&n2);
    for (i=1;i<=n1;i++)
    {
        result=result*n2;
    }
    printf("The result is: %d\n",result);
}
