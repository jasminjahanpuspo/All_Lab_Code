#include<stdio.h>
int main()
{
    int n,i,sum=0;
    printf("Enter N=");
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        if (i%2==0)
            sum=sum+1;
        else
            continue;
    }
    printf("The sum = %d\n",sum);
}
