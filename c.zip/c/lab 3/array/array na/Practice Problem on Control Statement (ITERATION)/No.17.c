#include<stdio.h>
int main()
{
    int i,n,x=0,y=1,z;
    printf("Enter N=");
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        if (i<=1)
        {
           z=i;
        }
        else
        {
            z=x+y;
            x=y;
            y=z;
        }
        printf("%d\n",z);
    }
}
