#include<stdio.h>
int main()
{
    int i,n,f;
    printf("Enter N=");
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        f=n/i;
        if (n%i==0)
            printf("%d\n",f);
    }
}
