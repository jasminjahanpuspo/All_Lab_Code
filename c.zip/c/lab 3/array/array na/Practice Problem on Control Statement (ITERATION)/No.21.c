#include<stdio.h>
int main()
{
    int n,i,sum=0;
    printf("Enter a number:");
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        sum=sum+n%10;
        n=n/10;
        if (n==0)
            break;
    }
    printf("The sum is: %d\n",sum);
}
