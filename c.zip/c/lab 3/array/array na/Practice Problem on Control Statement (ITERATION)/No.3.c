#include<stdio.h>
int main()
{
    int i,n,square,cube;
    float squareRoot;
    printf("Enter N=");
    scanf("%d",&n);
    for (i=0;i<=n;i++)
    {
        square=i*i;
        cube=i*i*i;
        squareRoot=sqrt(i);
        printf("%d  %d  %d  %.2f\n",i,square,cube,squareRoot);
    }
}
