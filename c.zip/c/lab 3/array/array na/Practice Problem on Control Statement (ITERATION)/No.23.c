#include<stdio.h>
int main()
{
    int n,num=0;
    printf("Enter a number:");
    scanf("%d",&n);
    while (n!=0)
    {
        n=n/10;
        num=num+1;
    }
    printf("The number of digits are: %d\n",num);
}
