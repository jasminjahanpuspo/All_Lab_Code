#include<stdio.h>
int main()
{
    int i,n1,n2;
    printf("Enter the two integers:");
    scanf("%d%d",&n1,&n2);
    if (n1>n2)
    {
        for (i=n2+1;i<n1;i++)
        {
            printf("%d ",i);
        }
    }
    else
    {
        for (i=n1+1;i<n2;i++)
        {
            printf("%d ",i);
        }
    }
}
