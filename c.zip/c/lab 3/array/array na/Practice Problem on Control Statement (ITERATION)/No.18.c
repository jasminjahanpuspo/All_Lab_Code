#include<stdio.h>
int main()
{
    int i,x=0,y=1,z;
    for (i=0;i<1000;i++)
    {
        if (i<=1)
        {
            z=i;
        }

        else
        {
            z=x+y;
            x=y;
            y=z;
            if (z>1000)
            break;
        }
        printf("%d ",z);
    }
}
