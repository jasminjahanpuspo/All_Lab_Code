#include<stdio.h>
int main()
{
    int i,x=0,y=1,z;
    for (i=0;i<10;i++)
    {
        if (i<=1)
        {
            z=i;
        }
        else
        {
            z=x+y;
            x=y;
            y=z;
        }
        printf("%d\n",z);
    }
}
