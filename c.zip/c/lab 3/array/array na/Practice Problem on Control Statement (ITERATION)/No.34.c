#include<stdio.h>
int main()
{
    int n1,n2,i,j,lcm;
    printf("Enter two numbers:");
    scanf("%d%d",&n1,&n2);
    if (n1>n2)
    {
        for (i=1;i;i++)
        {
            if ((i*n1)%n2==0)
            {
                lcm=i*n1;
                break;
            }
        }
    }
    else
    {
        for(j=1;j;j++)
        {
            if ((j*n2)%n1==0)
            {
                lcm=j*n2;
                break;
            }
        }
    }
    printf("The LCM is: %d\n",lcm);
}
