#include<stdio.h>
int main()
{
    int i=0,n1,n2;
    printf("Enter two integers:");
    scanf("%d%d",&n1,&n2);
    while (i<n1+n2)
    {
        printf("NEUB\n");
        i++;
    }
}
