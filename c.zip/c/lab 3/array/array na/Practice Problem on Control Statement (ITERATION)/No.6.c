#include<stdio.h>
int main()
{
    int i=1;
    while (i<=100)
    {
        printf("%d ",i);
        i=i+2;
    }
}
