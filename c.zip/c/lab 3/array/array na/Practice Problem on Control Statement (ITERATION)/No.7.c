#include<stdio.h>
int main()
{
    int i;
    while (i!=0)
    {
        printf("Enter N=");
        scanf("%d",&i);
        if (i>0)
            printf("Positive\n");
        else if (i<0)
            printf("Negative\n");
    }
}
