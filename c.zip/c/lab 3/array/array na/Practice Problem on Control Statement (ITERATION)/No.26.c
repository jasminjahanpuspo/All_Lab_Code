#include<stdio.h>
int main()
{
    int n,i,flag=0;
    printf("Enter a number:");
    scanf("%d",&n);
    for (i=2;i<=n/2;i++)
    {
        if (n%i==0)
        {
            flag=1;
            break;
        }
    }
    if (flag==0 && n!=1)
    {
        printf("This is a prime number.\n");
    }
    else
    {
        printf("This is not a prime number.\n");
    }
}
