#include<stdio.h>
int main()
{
    int n,i,x=0,y=0,sum=0;
    printf("Enter N=");
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        x=x+1;
        y=y+x;
        sum=sum+y;
    }
    printf("The sum = %d\n",sum);
}
