#include<stdio.h>
int main()
{
    int n,w,x,y,z;
    printf("Enter a number:");
    scanf("%d",&n);
    if (n==0)
    {
        printf("Zero");
    }
    if (n>=1000)
    {

            w=(n/1000);
        n=n%1000;
        switch(w)
        {
            case 1:
             printf("One Thousand ");
             break;
            case 2:
             printf("Two Thousand ");
             break;
            case 3:
             printf("Three Thousand ");
             break;
            case 4:
             printf("Four Thousand ");
             break;
            case 5:
             printf("Five Thousand ");
             break;
            case 6:
             printf("Six Thousand ");
             break;
            case 7:
             printf("Seven Thousand ");
             break;
            case 8:
             printf("Eight Thousand ");
             break;
            case 9:
             printf("Nine Thousand ");
             break;
        }
    }
    if (n<1000)
    {
        x=n/100;
        n=n%100;
        switch(x)
        {
        case 1:
            printf("One Hundred ");
            break;
        case 2:
            printf("Two Hundred ");
            break;
        case 3:
            printf("Three Hundred ");
            break;
        case 4:
            printf("Four Hundred ");
            break;
        case 5:
            printf("Five Hundred ");
            break;
        case 6:
            printf("Six Hundred ");
            break;
        case 7:
            printf("Seven Hundred ");
            break;
        case 8:
            printf("Eight Hundred ");
            break;
        case 9:
            printf("Nine Hundred ");
            break;
        }
    }
    if (n<100)
    {
        if (n>20)
        {
            y=n/10;
            switch(y)
            {
            case 2:
             printf("Twenty ");
             break;
            case 3:
             printf("Thirty ");
             break;
            case 4:
             printf("Forty ");
             break;
            case 5:
             printf("Fifty ");
             break;
            case 6:
             printf("Sixty ");
             break;
            case 7:
             printf("Seventy ");
             break;
            case 8:
             printf("Eighty ");
             break;
            case 9:
             printf("Ninety ");
             break;
            }
        }
        else if (n>=10)
        {
            y=10+(n%10);
            switch(y)
            {
            case 10:
             printf("Ten");
             break;
            case 11:
             printf("Eleven");
             break;
            case 12:
             printf("Twelve");
             break;
            case 13:
             printf("Thirteen");
             break;
            case 14:
             printf("Fourteen");
             break;
            case 15:
             printf("Fifteen");
             break;
            case 16:
             printf("Sixteen");
             break;
            case 17:
             printf("Seventeen");
             break;
            case 18:
             printf("Eighteen");
             break;
            case 19:
             printf("Nineteen");
             break;
            }
        }
    }
    if (n<100 && n/10!=1)
    {
        z=n%10;
        switch(z)
        {
        case 1:
         printf("One");
         break;
        case 2:
         printf("Two");
         break;
        case 3:
         printf("Three");
         break;
        case 4:
         printf("Four");
         break;
        case 5:
         printf("Five");
         break;
        case 6:
         printf("Six");
         break;
        case 7:
         printf("Seven");
         break;
         case 8:
        printf("Eight");
         break;
         case 9:
        printf("Nine");
         break;
        }
    }
}
