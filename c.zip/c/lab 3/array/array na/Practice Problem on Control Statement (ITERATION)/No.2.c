#include<stdio.h>
int main()
{
    int i;
    printf("The complete ASCII chart is printed below:\n\n");
    for (i=0;i<=255;i++)
        printf("%d   %c\n",i,i);
}

