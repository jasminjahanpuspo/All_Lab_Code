#include<stdio.h>
int main()
{
    int i,j;
    for (i=0;i<7;i++)
    {
        for (j=65;j<=71-i;j++)
        {
            printf("%c",j);
        }
        for (j=0;j<i;j++)
        {
            printf("  ");
        }
        printf("\b");
        for (j=71;j>=65+i;j--)
        {
            printf("%c",j-i);
        }
        printf("\n");
    }
}
