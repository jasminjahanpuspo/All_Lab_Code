#include<stdio.h>
int main()
{
    int i,j;
    for (i=0;i<6;i++)
    {
        for (j=0;j<=i;j++)
        {
            if (i%2==0)
            {
               printf("*");
               break;
            }
            else
            {
                if (j==4)
                    continue;
                else if (j==i && i>2)
                    continue;
                else
                    printf("*");
            }
        }
        printf("\n");
    }
}
