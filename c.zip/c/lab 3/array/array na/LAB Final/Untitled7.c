#include<stdio.h>
int main()
{
    int n,i,sum=0;
    scanf("%d",&n);

    for (i=1;i<=n;i++)
    {
        if (i%6==1)
            sum=sum+1;
        else if (i%6==2)
            sum=sum-2;
        else if (i%6==3)
            sum=sum+3;
        else if (i%6==4)
            sum=sum-1;
        else if (i%6==5)
            sum=sum+2;
        else if (i%6==0)
            sum=sum-3;
    }
    printf("The sum= %d\n",sum);
}
