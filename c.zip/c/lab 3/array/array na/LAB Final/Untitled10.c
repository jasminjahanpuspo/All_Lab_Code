#include<stdio.h>
int main()
{
    int n,n1,i,j,gcd;
    for (i=0;i<5;i++)
    {
        scanf("%d",&n);
        if (i==0)
        {
            n=n1;
        }
        else
        {
            if (n1<n)
            {
                for (j=1;j<=n1;j++)
                {
                    if (n1%j==0 && n%j==0)
                    {
                        gcd=j;
                    }
                }
            }
            else
            {
                for (j=1;j<=n;j++)
                {
                    if (n1%j==0 && n%j==0)
                    {
                        gcd=j;
                    }
                }
            }
        }
        n1=gcd;
    }
    printf("Final GCD = %d\n",gcd);
}
