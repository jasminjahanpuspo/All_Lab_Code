#include<stdio.h>
int main()
{
    int i,j,x=1;

    for (i=1;i<=4;i++)
    {
        for (j=1;j<i;j++)
            printf("  ");

        for (j=9;j>i*2;j--)
        {
            if (x%2==1)
                printf("%c ",174);
            else
                printf("%c ",175);
            x++;
        }
        printf("\n");
    }
}
