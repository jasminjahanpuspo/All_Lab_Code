#include<stdio.h>
int main()
{
    int i,j,x=0;

    for (i=1;i<=4;i++)
    {
        for (j=1;j<i;j++)
        {
            printf("  ");
        }
        for (j=9;j>i*2;j--)
        {
            printf("%d ",x);
            x++;
            if (x>9)
                x=0;
        }
        printf("\n");
    }
}
