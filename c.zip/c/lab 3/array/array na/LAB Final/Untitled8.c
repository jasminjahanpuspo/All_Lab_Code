#include<stdio.h>
int main()
{
    int i,x=0,y=1,z;

    for (i=0;i<500;i++)
    {
        if (i<=1)
        {
            z=i;
        }
        else
        {
            z=x+y;
            x=y;
            y=z;
        }
        if (i%2==0)
            printf("%d\n",z);
        if (z>500)
            break;
    }
}
