#include<stdio.h>
int main()
{
    int i,j,x,y,gcd,sum=0;

    for (i=1;i<=4;i++)
    {
        scanf("%d%d",&x,&y);

        if (x<y)
        {
            for (j=1;j<=x;j++)
            {
                if (x%j==0 && y%j==0)
                    gcd=j;
            }
        }
        else
        {
            for (j=1;j<=y;j++)
            {
                if (x%j==0 && y%j==0)
                    gcd=j;
            }
        }
        sum=sum+gcd;
    }
    if (sum%2==0)
        printf("YES");
    else
        printf("NO");
}
