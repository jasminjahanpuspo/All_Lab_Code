#include<stdio.h>
int main()
{
    int i,x=0,y=1,z,sum=0;

    for (i=0;i<100;i++)
    {
        if (i<=1)
            z=i;
        else
        {
            z=x+y;
            x=y;
            y=z;
        }
        if (z>=100)
            break;
        if (z%2==0)
            sum=sum+z;
    }
    printf("Sum = %d\n",sum);
}
