#include<stdio.h>
int main()
{
    int  n,i,sum=0;
    scanf("%d",&n);

    for (i=1;i<=n;i++)
    {
        if (i%3==1)
            sum=sum+1;
        else if (i%3==2)
            sum=sum+2;
        else if (i%3==0)
            sum=sum+3;
    }
    printf("The sum= %d\n",sum);
}
