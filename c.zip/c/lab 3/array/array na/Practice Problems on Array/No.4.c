#include<stdio.h>
int main ()
{
    int n[6],i,lrst,lrst2;

    for (i=0;i<6;i++)
        scanf("%d",&n[i]);

    lrst=n[0];
    lrst2=n[1];
    for (i=0;i<6;i++)
    {
        if (n[i]>lrst)
        {
            lrst2=lrst;
            lrst=n[i];
        }
        if (lrst>n[5] && n[5]>lrst2)
        {
            lrst2=n[5];
        }
    }
    printf("The largest= %d and the second largest= %d\n",lrst,lrst2);
}
