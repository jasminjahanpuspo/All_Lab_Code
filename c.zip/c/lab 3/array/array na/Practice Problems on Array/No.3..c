#include<stdio.h>
int main()
{
    int n[5]={21,33,5,21,67};
    int min=n[0],i;
    for (i=0;i<5;i++)
    {
        if (min>n[i])
        {
            min=n[i];
        }
    }
    printf("Minimum= %d\n",min);
}
