#include<stdio.h>
int main()
{
    int a[3][3];
    int i,j,sum=0;
    for (i=0;i<3;i++)
        for (j=0;j<3;j++)
            scanf("%d",&a[i][j]);
    sum=sum+a[0][2];
    sum=sum+a[1][1];
    sum=sum+a[2][0];

    printf("The sum is: %d\n",sum);
}
