#include<stdio.h>
int main()
{
    int n[3][3],i,j,sum;

    for (i=0;i<3;i++)
        for (j=0;j<3;j++)
            scanf("%d",&n[i][j]);

    for (i=0;i<3;i++)
    {
        sum=0;
        for (j=0;j<3;j++)
            sum=sum+n[i][j];

        printf("The summation of Row %d = %d\n",i+1,sum);
    }

}

