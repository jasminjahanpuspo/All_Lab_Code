#include<stdio.h>
int main()
{
    int n[8]={65,78,43,94,24,54,76,32};
    int i;
    for (i=0;i<8;i++)
    {
        printf("%d\n",n[i]);
    }
    printf("\nThe array in reverse order:\n");
    for (i=7;i>=0;i--)
    {
        printf("%d\n",n[i]);
    }
}
