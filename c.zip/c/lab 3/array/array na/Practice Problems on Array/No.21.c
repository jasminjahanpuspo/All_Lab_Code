#include<stdio.h>
int main()
{
    int r,c,i,j,k,m,det=0;
    printf("Enter No. of row:");
    scanf("%d",&r);
    printf("Enter No. of column:");
    scanf("%d",&c);

    int a[r][c];
    int co[r][c];
    float in[r][c];

    if ((c==2 && r==2 ) || (c==3 && r==3))
    {
        for (i=0;i<r;i++)
            for (j=0;j<c;j++)
                scanf("%d",&a[i][j]);

        if (r==2 && c==2)
        {
            det=det+((a[0][0]*a[1][1])-(a[0][1]*a[1][0]));
            co[0][0]=a[1][1];
            co[0][1]=-a[0][1];
            co[1][0]=-a[1][0];
            co[1][1]=a[0][0];

        }
        else if (r==3 && c==3)
        {
            det=det+a[0][0]*((a[1][1]*a[2][2])-(a[2][1]*a[1][2]));
            det=det-a[1][1]*((a[1][0]*a[2][2])-(a[2][0]*a[1][2]));
            det=det+a[0][2]*((a[1][0]*a[2][1])-(a[2][0]*a[1][1]));
            co[0][0]=((a[1][1]*a[2][2])-(a[2][1]*a[1][2]));
            co[0][1]=-((a[0][1]*a[2][2])-(a[2][1]*a[0][2]));
            co[0][2]=((a[0][1]*a[1][2])-(a[1][1]*a[0][2]));
            co[1][0]=-((a[1][0]*a[2][2])-(a[2][0]*a[1][2]));
            co[1][1]=((a[0][0]*a[2][2])-(a[2][0]*a[0][2]));
            co[1][2]=-((a[0][0]*a[1][2])-(a[1][0]*a[0][2]));
            co[2][0]=((a[1][0]*a[2][1])-(a[2][0]*a[1][1]));
            co[2][1]=-((a[0][0]*a[2][1])-(a[2][0]*a[0][1]));
            co[2][2]=((a[0][0]*a[1][1])-(a[1][0]*a[0][1]));


        }
        if (det<0)
        {
            det=-det;
            printf("The inverse of the matrix is:\n-(1/%2d)",det);

        }
        else
        {
            printf("The inverse of the matrix is:\n(1/%2d)",det);
        }

        for (k=0;k<r;k++)
        {
            printf("|");
            for (m=0;m<c;m++)
            {
                printf("%4d   ",co[k][m]);
            }
            printf("\b\b\b|\n\t");
        }
    }
    else
    {
        printf("This is an invalid order.\n");
    }
}
