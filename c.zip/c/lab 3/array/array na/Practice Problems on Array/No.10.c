#include<stdio.h>
int main()
{
    int i,j,f[6],n[6]={10,20,30,40,10,20};
    int flag;
    for (i=0;i<6;i++)
    {
        f[i]=1;
    }
    for (i=0;i<6;i++)
    {
        for (j=0;j<i;j++)
        {
            if (n[i]==n[j])
            {
                f[i]=f[i]+1;
                break;
            }
            printf("The frequency of %d is %d\n",n[i],f[i]);
        }

    }



}
