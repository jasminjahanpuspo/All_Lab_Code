#include<stdio.h>
int main()
{
    float n[50];
    int i,sum=0;
    for (i=0;i<50;i++)
    {
        scanf("%f",&n[i]);
        sum=sum+(int)n[i];
    }
    printf("The sum= %d\n",sum);
}
