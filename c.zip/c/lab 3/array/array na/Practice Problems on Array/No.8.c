#include<stdio.h>
int main()
{
    int i,x,y,temp,n[6]={23,32,45,67,88,21};

    printf("Enter two positions:");
    scanf("%d%d",&x,&y);

    for (i=0;i<6;i++)
        printf("%d\n",n[i]);

    printf("\n\n");

    temp=n[y-1];
    n[y-1]=n[x-1];
    n[x-1]=temp;

    for (i=0;i<6;i++)
        printf("%d\n",n[i]);
}
