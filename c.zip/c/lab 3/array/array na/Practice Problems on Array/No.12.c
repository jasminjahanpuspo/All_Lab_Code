#include<stdio.h>
int main()
{
    int s,i;
    printf("Enter the size of the array:");
    scanf("%d",&s);
    int n[s],max,min;
    for (i=0;i<s;i++)
    {
        scanf("%d",&n[i]);
    }
    min=n[0];
    for (i=0;i<s;i++)
        if (min>n[i])
        {
            min=n[i];
        }
    max=n[0];
    for (i=0;i<s;i++)
        if (max<n[i])
        {
            max=n[i];
        }

    printf("%d and %d are the elements whose difference is largest.\n",min,max);
}
