#include<stdio.h>
int main()
{
    int n[5]={45,65,34,17,10};
    int n1,loc,i;
    printf("Enter a data:");
    scanf("%d",&n1);
    printf("Enter a location:");
    scanf("%d",&loc);

    for (i=0;i<5;i++)
    {
        printf("%d\n",n[i]);
    }
    printf("\n\n");
    for (i=0;i<5;i++)
    {
        if (loc==i+1)
            n[i]=n1;
        printf("%d\n",n[i]);
    }
}
