#include<stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    int n[size];
    int i,j,flag;
    for (i=0;i<size;i++)
        scanf("%d",&n[i]);
    printf("All the unique numbers are:\n");
    for (i=0;i<size;i++)
    {
        flag=0;
        for (j=0;j<i;j++)
        {
            if (n[i]==n[j])
                flag=1;
        }
        if (flag==0)
            printf("%d\n",n[i]);
    }
}
