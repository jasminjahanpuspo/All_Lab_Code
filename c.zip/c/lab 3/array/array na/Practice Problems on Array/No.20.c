#include<stdio.h>
int main()
{
    int a[3][3];
    int i,j,se=0,sz=0;
    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
            se=se+1;
            if (a[i][j]==0)
            {
                sz=sz+1;
            }
        }
    }
    if (sz>se/2)
        printf("The matrix is sparse.\n");
    else
        printf("The matrix is not sparse.\n");
}
