#include<stdio.h>
int main()
{
    int n[10]={12,23,45,45,65,34,55,97,23,66};
    int i;
    for (i=0;i<10;i++)
    {
        if (n[i]%2!=0)
        {
            n[i]=1;
            printf("%d ",n[i]);
        }
        else
        {
            n[i]=0;
            printf("%d ",n[i]);
        }
    }
}
