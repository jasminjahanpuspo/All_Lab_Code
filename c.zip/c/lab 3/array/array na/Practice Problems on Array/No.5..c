#include<stdio.h>
int main()
{
    int n[5]={23,-44,9,-6,-12};
    int i;
    for (i=0;i<5;i++)
    {
        printf("%d\n",n[i]);
    }
    printf("\n\n");
    for (i=0;i<5;i++)
    {
        if (n[i]<0)
        {
             n[i]=-n[i];
        }
        printf("%d\n",n[i]);
    }
}
