#include<stdio.h>
int main()
{
    int n[5],i,max,max2;

    for (i=0;i<5;i++)
    {
        scanf("%d",&n[i]);
    }
    max=n[0];

    for (i=1;i<5;i++)
    {
        if (n[i]>max)
            max=n[i];
    }

    for (i=0;i<5;i++)
    {
        if (n[i]==max)
        {
            continue;
        }
        else
        {
            if (max2<n[i])
                max2=n[i];
        }
    }
    printf("\nMaximum= %d and 2nd Minimum= %d\n",max,max2);
}
