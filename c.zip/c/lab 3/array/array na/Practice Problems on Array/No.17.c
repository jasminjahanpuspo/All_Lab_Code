#include<stdio.h>
int main()
{
    int n[4][3],i,j;

    for (i=0;i<4;i++)
        for (j=0;j<3;j++)
            scanf("%d",&n[i][j]);

    printf("\nThe Transpose of this matrix is:\n");

    for (j=0;j<3;j++)
    {
        for (i=0;i<4;i++)
            printf("%d ",n[i][j]);
        printf("\n");
    }
}
