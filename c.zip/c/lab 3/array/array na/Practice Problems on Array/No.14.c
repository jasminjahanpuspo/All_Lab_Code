#include<stdio.h>
int main()
{
    int a[3][3],i,j,flag=0;

    int b[3][3]={{1,0,0},{0,1,0},{0,0,1}};

    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
            if (a[i][j]!=b[i][j])
            {
                flag=1;
                continue;
            }
        }
    }
    if (flag==0)
        printf("This is an identity matrix.\n");
    else
        printf("This is not an identity matrix.\n");
}
