#include<stdio.h>
int main()
{
    int n[5],i,sum=0,a;
    for(i=0; i<5; i++)
    {
        scanf("%d",&n[i]);

    }
    for(i=4; i>=0; i--)
    {
        printf("The reverse order is %d\n\n",n[i]);
    }
}
