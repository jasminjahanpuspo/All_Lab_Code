#include<stdio.h>
int main()
{
    int a[5],i,max,min;
    for(i=0; i<5; i++)
    {
        scanf("%d",&a[i]);

    }
    max=a[0];
    for(i=1; i<5; i++)
    {
        if(a[i]>max)
            max=a[i];
    }
    printf("max %d\n",max);
    min=a[0];
    for(i=0; i<5; i++)
    {
        if(a[i]<min)
        {
            min=a[i];
        }
    }
    printf("min %d\n",min);
    printf("\ndifference %d",max-min);

}
