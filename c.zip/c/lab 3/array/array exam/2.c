#include<stdio.h>
int main()
{
    int  a[2],i;
    for(i=0; i<2; i++)
    {
        scanf("%d",&a[i]);

    }
    for(i=0; i<2 ;i++)
    {
        if(a[i]%2==0)
            {
                a[i]=0;
                //printf("%d\n",a[i]);
            }

        else
           {
               a[i]=1;
               //printf("%d",a[i]);
           }

    }
}
