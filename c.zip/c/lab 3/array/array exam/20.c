#include<stdio.h>
int main()
{
    int a[2][2],se=0,sz=0,i,j;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2;j++)
        {
            scanf("%d",&a[i][j]);
            se+=1;
            if(a[i][j]==0)
            {
                sz+=1;
            }
        }
    }
    if(sz>se/2)
    {
        printf("sapse");
    }
    else
        printf("not");
}
