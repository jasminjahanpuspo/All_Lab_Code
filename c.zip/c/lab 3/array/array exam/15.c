#include<stdio.h>
int main()
{
    int a[3][3],b[3][3],i,j,flag=0;
    printf("first");
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("first");
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            if(a[i][j]!=b[i][j])
            {
                flag=1;
                continue;
            }
        }
    }
    if(flag==0)
    {
        printf("qual");
    }
    else
        printf("not");
}
