#include<stdio.h>
int main()
{
    int a[3],i,min,max;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    for(i=0; i<3; i++)
    {
        if(a[i]>max)
            max=a[i];
    }
    printf("max %d\n",max);
    for(i=0; i<3; i++)
    {
        if(max!=a[i])
        {
            min=a[i];
        }
    }
    printf("min %d",min);
}
