#include<stdio.h>
int main()
{
    int a[3],i,j,flag;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    printf("unt");
    for(i=0; i<3; i++)
    {
        flag=0;
        for(j=0; j<3; j++)
        {
            if(a[i]==a[j])
                flag=1;
        }
        if(flag==0)
    {
        printf("%d",a[i]);
    }
    }
   /* if(flag==0)
    {
        printf("%d",a[i]);
    }*/
}
