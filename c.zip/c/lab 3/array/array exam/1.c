#include<stdio.h>
int main()
{
    float a[3],sum=0;
    int i;
    for(i=0;i<3;i++)
    {
        scanf("%f",&a[i]);
        sum=sum+a[i];
    }
    printf("%.f\n",sum);

}
