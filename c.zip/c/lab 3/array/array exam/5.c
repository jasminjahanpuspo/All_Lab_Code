#include<stdio.h>
int main()
{
    int a[3],i,posi;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<3; i++)
    {
        if(a[i]<0)
            {
                posi=a[i]*-1;
            printf("\n%d\n",posi);
            }
            else
                printf("%d",a[i]);

    }

}
