#include<stdio.h>
int main()
{
    int a[3],i;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    int data;
    scanf("%d%d",&i,&data);

    a[i]=data;
    for(i=0; i<3; i++)
    {
        printf("a[%d]=%d",i,a[i]);
    }
}
