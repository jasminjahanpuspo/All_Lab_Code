#include<stdio.h>
int main()
{
    int a[3],i,min;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    min=a[i];
    for(i=0; i<3; i++)
    {
        if(a[i]<min)
        {
            min=a[i];
        }
    }
            printf("\n\n%d\n\n",min);


}
