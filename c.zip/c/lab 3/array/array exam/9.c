#include<stdio.h>
int main()
{
    int a[3],i,even=0,odd=0;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<3; i++)
    {
        if(a[i]%2==0)
            even++;
        else
            odd++;
    }
    printf("even %d\n",even);
    printf("odd %d\n",odd);
}
