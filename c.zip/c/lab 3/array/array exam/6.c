#include<stdio.h>
int main()
{
   int a[3],i,p[3];
   for(i=0; i<3; i++)
   {
       scanf("%d",&a[i]);
   }
   for(i=2; i>=0; i--)
   {
       p[i]=a[i];
       printf("\n%d\t",p[i]);
   }
}
