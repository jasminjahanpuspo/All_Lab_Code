#include<stdio.h>
int main()
{
    int a[3][3],b[3][3],i,j,flag=0;
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            if(i==j){
            printf("1 ",a[i][j]);
            }
            else
                printf("0 ",a[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            scanf("%d",&b[i][j]);
            if(b[i][j]!=a[i][j])
            {
                flag=1;
                continue;
            }
        }
    }
    if(flag==0)
    {
        printf("identity");
    }
    else
        printf("not");
}
