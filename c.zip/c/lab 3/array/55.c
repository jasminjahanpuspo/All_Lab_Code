#include<stdio.h>
enum day{sat,sun,mon};
int main()
{
    char *day[]={"sat","sun","mon"};
    enum day today =sun;
    enum day nextday= today+1;
    printf("%s",day[today]);
    printf("%s",nextday);
}
