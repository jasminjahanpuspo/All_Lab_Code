#include<stdio.h>
int main()
{
    int n[5]={1,2,3,4,5};
    int m[5]={6,7,8,9,10};
    int i;
    for(i=0; i<5; i++)
    {
        printf("The add of corresponding element %d\n\n",n[i]+m[i]);
    }
}
