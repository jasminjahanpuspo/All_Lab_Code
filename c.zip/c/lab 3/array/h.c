#include<stdio.h>
int main()
{
    int i,n[5];
    for(i=0; i<5; i++)
    {
        scanf("%d",&n[i]);
    }
    for(i=0; i<5; i++)
    {
        if(n[i]%2==1)
        {
            printf("in odd order %d\n\n",n[i]);
        }
    }
}
