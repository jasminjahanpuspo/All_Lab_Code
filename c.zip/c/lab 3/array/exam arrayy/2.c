#include<stdio.h>
int main()
{
    int max,i,a[3];
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    for(i=0; i<3; i++)
    {
        if(a[i]>=max)
        {
            max=a[i];
        }
    }
    printf("max %d\n",max);
    int min;
    min=a[0];
    for(i=0; i<3; i++)
    {
        if(a[i]<min)
            min=a[i];
    }
    printf("min %d\n",min);
    int lar;
    for(i=0; i<3; i++)
    {
        if(a[i]!=max)
            lar=a[i];
    }
    printf("largest %d\n",lar);
    printf("Difference %d\n",max-min);
}
