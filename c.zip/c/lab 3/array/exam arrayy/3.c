#include<stdio.h>
int main()
{
    int a[3],i;
   for(i=0; i<3; i++)
   {
       scanf("%d",&a[i]);
   }
   int data,loc=-1;
   scanf("%d",&data);
   for(i=0; i<3; i++)
   {
       if(data==a[i])
       {
           loc=i+1;
           break;
       }
   }
   if(loc==-1)
   {
       printf("Error.\n");
   }
   else
   {
       printf("Found %d",loc);
   }

}
