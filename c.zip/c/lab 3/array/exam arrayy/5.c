#include<stdio.h>
int main()
{
    int n,temp;
    scanf("%d",&n);
    int a[n],i;
    for(i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
    }
    if(a[n]%2==1)
    {
        printf("error");
    }
    else
    {
        for(i=1; i<n; i+=2)
        {
            temp=a[i];
            a[i]=a[i-1];
            a[i-1]=temp;
        }
    }
     for(i=0; i<n; i++)
     {
         printf("\n%d\t",a[i]);
     }

}
