#include<stdio.h>
int main()
{
    int n,sum=0;
    scanf("%d",&n);
    int a[n],i;
    for(i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
         sum=sum+a[i];
    }
    for(i=0; i<n; i++)
    {
       printf("%d\t",a[i]);

    }
    printf("\n\nsum %d",sum);

}
