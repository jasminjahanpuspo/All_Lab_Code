#include<stdio.h>
int main()
{
    int n[3];
    n[0]=10;
    n[1]=20;
    n[2]=30;
    printf("%d\t%d\t%d\t\n",n[0],n[1],n[2]);
}
