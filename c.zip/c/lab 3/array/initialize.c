#include<stdio.h>
int main()
{
    int n[4]={10,20,30,40},i;
    for(i=0; i<4; i++)
    {
        printf("%d\t",n[i]);
    }

}

