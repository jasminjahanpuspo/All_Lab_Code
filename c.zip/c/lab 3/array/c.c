#include<stdio.h>
int main()
{
    int n[2],sum;
    n[0]=10;
    n[1]=20;
    sum=n[0]+n[1];
    printf("sum is = %d\n\n",sum);
    int i;
    for(i=0; i<1; i++)
    printf("address of n[0] & n[1] are : %d & %d \t\n\n",&n[i]);
}
