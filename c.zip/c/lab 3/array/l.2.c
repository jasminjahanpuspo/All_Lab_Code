#include<stdio.h>
int main()
{
    int n[5],m[5],i;
    for(i=0; i<5; i++)
    {
        scanf("%d",&n[i]);
        scanf("%d",&m[i]);
        printf(" The add are %d\n\n",n[i]+m[i]);
    }
}
