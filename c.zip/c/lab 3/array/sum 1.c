#include<stdio.h>
int main()
{
    int n[3],sum;
    n[0]=1;
    n[1]=2;
    n[2]=3;
    sum=n[0]+n[1]+n[2];
    printf("%d",sum);
}
