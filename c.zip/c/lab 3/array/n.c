#include<stdio.h>
int main()
{
    int n[6]={10,20,30,40,50,60};
    int size=6,i,temp;
    if(size%2==1)
    {
        printf("Array size is not even.");
    }
    else
    {
        for(i=1; i<6; i++)
        {
            temp=n[i];
            n[i]=n[i-1];
            n[i-1]=temp;
        }
        for(i=0; i<6; i++)
        {
            printf("Swaps number are %d\n\n",n[i]);
        }
    }
}
