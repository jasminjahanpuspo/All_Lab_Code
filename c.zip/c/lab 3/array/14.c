#include<stdio.h>
int main()
{
    int m,n,i,j;
    printf("Hoe many col & row");
    scanf("%d%d",&m,&n);
    int [m][n];
    printf("Identity matrix");
    for(i=0; i<n;i++)
    {
        for(j=0; j<n;j++)
        {
            if(i==j)
            {
                printf("1",a[i][j]);
            }
            else
                printf("0",a[i][j]);
        }
        printf("\n");
    }
    printf(Enter a matrix);
    int b[m][n],x,y;

}
