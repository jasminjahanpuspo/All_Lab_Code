#include<stdio.h>
int main()
{
    int n[3],sum=0,i;
    for(i=0; i<3; i++)
    {
        n[i]=i+1;
        sum=sum+n[i];
    }
    printf("%d\n\n",sum);
    for(i=0; i<3; i++)
    {
        printf("%d\t",n[i]);
    }
}
