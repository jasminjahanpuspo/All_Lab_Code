#include<stdio.h>
int main()
{
    int n[2]={1,2,3,4},i;
    for(i=0; i<4; i++)
    {
        printf("%d\n\n",&n[i]);
    }
}
