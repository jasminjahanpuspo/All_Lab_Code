#include<stdio.h>
int main()
{
    int n[5],p[5],i;
    for(i=0; i<5; i++)
    {
        scanf("%d",&n[i]);

    }
    for(i=0; i<5; i++)
    {
        p[i]=n[i];
    }
    for(i=0; i<5; i++)
    {
        printf("The copy number are %d\n\n",p[i]);
    }
}
