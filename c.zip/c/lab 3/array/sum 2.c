#include<stdio.h>
int main()
{
    int i,sum=0,n[3];
    for(i=0; i<3; i++)
    {
        scanf("%d",&n[i]);
        sum=sum+n[i];
    }
    printf("%d",sum);
}
