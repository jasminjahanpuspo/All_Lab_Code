#include<stdio.h>
int main()
{
    int n[5],i,max;
    for(i=0; i<5; i++)
    {
        scanf("%d",&n[i]);
    }
    max=n[0];
    for(i=1; i<5; i++)
    {
        if(n[i]>=max)
        {
            max=n[i];
        }
    }
    printf("\n\nThe maximum number is %d\n\n",max);

}
