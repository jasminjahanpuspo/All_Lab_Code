#include<stdio.h>
int main()
{
    int a=10,b=20;
    int *p,*q;
    p=&a;
    *p=a;
    b=*p;

    a=*p;
    printf("%d,%d",a,b);
   *q=&b;
    *q=b;
    a=*q;
    printf("%d,%d",a,b);*/
}
