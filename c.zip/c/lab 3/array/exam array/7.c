#include<stdio.h>
int main()
{
    int a[4],i,temp;
    for(i=0; i<4; i++)
    {
        scanf("%d",&a[i]);
    }
    if(a[4]%2==1)
    {
        printf("error");
    }
    else
        for(i=0; i<4; i=i+2)
    {
        temp=a[i];
        a[i]=a[i+1];
        a[i+1]=temp;
    }
    for(i=0; i<4; i++)

         printf("%d\t\t",a[i]);
}
