#include<stdio.h>
int main()
{
    int i,a[3];
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
        if(a[i]>0)
        {
            printf("%d\n",a[i]);
        }
        else
        {
            printf("%d\n",a[i]*-1);
        }
    }
}
