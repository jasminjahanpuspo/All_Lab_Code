#include<stdio.h>
int main()
{
    int a[5],i;
    for(i=0; i<5; i++)
    {
        scanf("%d",&a[i]);
    }
    int f,s;
    f=a[0];
    for(i=1; i<5; i++)
    {
        if(a[i]>=f)
        {
            f=a[i];
        }

    }
    printf("%d\n",f);
    for(i=0; i<5; i++)
    {
        if(f!=a[i])
        {
            s=a[i];
        }
    }
    printf("\n%d",s);
}
