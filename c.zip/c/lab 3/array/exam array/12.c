#include<stdio.h>
int main()
{
    int size,i,max,min;
    scanf("%d",&size);
    int a[size];
    for(i=0; i<size ;i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    for(i=0; i<size; i++)
    {
        if(a[0]<a[i])
            max=a[i];
    }
    printf("max is %d\n",max);
    min=a[0];
    for(i=0; i<size; i++)
    {
        if(a[0]>a[i])
            min=a[i];
    }
    printf("min is %d\n",min);
    printf("The differ is 2 lagest %d",max-min);

}
