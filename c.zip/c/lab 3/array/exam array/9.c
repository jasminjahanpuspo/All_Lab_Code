#include<stdio.h>
int main()
{
    int i,size,odd=0,even=0;
    scanf("%d",&size);
    int a[size];
    for(i=0; i<size; i++)
    {
        scanf("%d",&a[i]);
        if(a[i]%2==1)
        {
            odd++;
        }
        else if(a[i]%2==0)
        {
            even++;
        }
    }
    printf("count odd %d\n\n",odd);
    printf("count even %d",even);
}
