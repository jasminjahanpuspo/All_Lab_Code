#include<stdio.h>
int main()
{
    int a[3],i;
    printf("%d\n\n",sizeof(int));
    a[0]=10;
    a[10>5]=20;
    a[2]=30;
    for(i=0; i<3; i++)
    {
        printf("%d,",a[i]);
    }
}
