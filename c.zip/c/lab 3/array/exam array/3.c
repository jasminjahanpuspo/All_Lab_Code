#include<stdio.h>
int main()
{
    int i,min,size;
    scanf("%d",&size);
    int a[size];
    min=a[0];
    for(i=0; i<size ;i++)
    {
        scanf("%d",&a[i]);
        if(min>=a[i])
        {
            min=a[i];
        }

    }
    printf("%d",min);
}
