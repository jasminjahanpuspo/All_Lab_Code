#include<stdio.h>
int main()
{
    int a[3]={10,20,30},i,data;
    for(i=0; i<3; i++)
    {
        printf("a[%d]=%d\n",i,a[i]);
    }
    scanf("%d%d",&i,&data);
    a[i]=data;
    for(i=0; i<3; i++)
    {
        printf("a[%d]=%d\n",i,a[i]);
    }
}
