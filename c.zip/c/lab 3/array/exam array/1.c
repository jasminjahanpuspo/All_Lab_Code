#include<stdio.h>
int main()
{
    float a[5];
    int i,sum=0;
    for(i=0;i<5;i++)
    {
        scanf("%f",&a[i]);
        sum=sum+a[i];
    }
    printf("%d",sum);
}
