#include<stdio.h>
int main()
{
    int i,p[3],a[3];
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);

    }
    for(i=0; i<3; i++)
    {
         p[i]=a[i];
    }
    for(i=2; i>=0; i--)
    {

        printf("%d\n",p[i]);
    }
}
