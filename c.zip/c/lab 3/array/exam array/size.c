#include<stdio.h>
int main()
{
    int a[3],x=0,i;
    int size=sizeof(a)/sizeof(a[0]);
    for(i=0; i<size; i++)
    {
        printf("%d\n",a[i]);
    }
}
