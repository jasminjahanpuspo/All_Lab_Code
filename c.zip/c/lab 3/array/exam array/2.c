#include<stdio.h>
int main()
{
    int a[3],i;
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
        if(a[i]%2==1)
        {
            printf("the odd replace by 1\n ");
        }
        else
            printf("the even replace by 0\n\n ");
    }
}
