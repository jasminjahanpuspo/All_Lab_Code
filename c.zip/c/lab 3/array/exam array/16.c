#include<stdio.h>
int main()
{
     int mat[3][3],tra[3][3],i,j,sum=0;
    printf(" first\n");
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }
    printf("ele\n");
    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            printf("%d\t",mat[i][j]);
            sum=sum+mat[i][j];
        }
         printf("\n");
    }
    printf("sum %d\t",sum);
    printf("\n");
    float r=sqrt(sum);
    printf("%f",r);
}
