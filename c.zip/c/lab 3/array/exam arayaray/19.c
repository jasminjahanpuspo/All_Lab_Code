#include<stdio.h>
int main()
{
    int a[2][2],i,j,sum=0;
    float rank;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            scanf("%d",&a[i][j]);
            sum+=a[i][j];
        }
    }
    printf("Sum is %d\n\n",sum);
    rank=sqrt(sum);
    printf("Rank is %f",rank);
}
