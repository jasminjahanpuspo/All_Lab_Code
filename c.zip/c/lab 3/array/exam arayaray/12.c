#include<stdio.h>
int main()
{
    int a[3],i,max,min,mzz;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    for(i=0; i<3; i++)
    {
        if(a[i]>max)
        {
            max=a[i];
        }
    }
    printf("%d",max);
    for(i=0; i<3; i++)

    {
        if(a[i]<min)
        {
            min=a[i];
        }
    }
    printf("%d",min);
    for(i=0; i<3; i++)
    {
        if(a[i]!=max){
        mzz=a[i];
        }
    }
    printf("%d",mzz);
    printf("%d",max-min);
    int odd=0,even=0;
    for(i=0; i<3; i++)
    {
        if(a[i]%2==1){
            odd++;
        }

        else
            even++;

    }
    printf("\n\n%dodd",odd);
    printf("%deven",even);
}
