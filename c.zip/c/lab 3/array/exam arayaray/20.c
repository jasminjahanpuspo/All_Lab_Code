#include<stdio.h>
int main()
{
    int a[2][2],i,j,zero=0,size=0;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            scanf("%d",&a[i][j]);
            size++;
            if(a[i][j]==0)
                zero++;
        }
    }
    if(zero>size/2)
    {
        printf("sparse");
    }
    else
    {
        printf("not");
    }
}
