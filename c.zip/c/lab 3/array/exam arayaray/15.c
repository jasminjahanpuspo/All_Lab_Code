#include<stdio.h>
int main()
{
    int m,n,a[m][n],b[m][n],i,j;
    scanf("%d%d",&m,&n);
    for(i=0; i<m;i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0; i<m;i++)
    {
        for(j=0; j<n; j++)
        {
            printf("%d\t",a[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<m;i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    for(i=0; i<m;i++)
    {
        for(j=0; j<n; j++)
        {
            printf("%d\t",b[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<m;i++)
    {
        for(j=0; j<n; j++)
        {
            if(a[i][j]==b[i][j]){
                printf("Eual");
                break;
            }
            else
                {
                    printf("not");
                }
        }
    }
}
