#include<stdio.h>
int main()
{
    int next,t1=0,t2=1,sum=0;
    int i;
    for(i=1; i<=10 ;i++)
    {
        if(i%2==1){
        printf("%d\t",t1);
        sum=sum+t1;
        next=t1+t2;
        //printf("%d\t",next);
        t1=t2;
        t2=next;
        }
        //}
    }
}
