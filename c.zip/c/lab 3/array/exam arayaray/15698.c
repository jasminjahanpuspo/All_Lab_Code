#include<stdio.h>
int main()
{
    unsigned char ch=-156;
    ch2=ch*5;
    printf("%d\n",ch2);
}
