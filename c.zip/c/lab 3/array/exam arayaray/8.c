#include<stdio.h>
int main()
{
    int a[3],i,x,y,temp;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<3; i++)
    {
        printf("%d\t",a[i]);
    }
    scanf("%d%d",&x,&y);
    temp=a[y-1];
    a[y-1]=a[x-1];
    a[x-1]=temp;
    for(i=0; i<3; i++)
    {
        printf("%d\n",a[i]);
    }

}
