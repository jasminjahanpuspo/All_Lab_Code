#include<stdio.h>
int main()
{
    int m,n,a[m][n],b[m][n],i,j,flag=0;
    scanf("%d%d",&m,&n);
    for(i=0; i<m;i++)
    {
        for(j=0; j<n; j++)
        {
            if(i==j)
                printf("1 ",a[i][j]);
            else
                printf("0 ",a[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&b[i][j]);
            if(b[i][j]!=a[i][j])
            {
                flag=1;
                continue;
            }
        }
    }
    if(flag==0)
    {
        printf("iden");
    }
    else
        printf("not");
}
