#include<stdio.h>
int main()
{
    int a[3],i,data;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d%d",&i,&data);
    a[i]=data;
    for(i=0; i<3; i++)
    {
        printf("%d",a[i]);
    }
}
