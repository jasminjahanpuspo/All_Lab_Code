#include<stdio.h>
int main()
{
    int a[3],i;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<3; i++)
    {
        printf("%d",a[i]);
        if(a[i]%2==0)
            a[i]=0;
        else
            a[i]=1;
    }
}
