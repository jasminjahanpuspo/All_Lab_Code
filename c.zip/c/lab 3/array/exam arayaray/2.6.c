#include<stdio.h>
int main()
{
    int n,a[n],i,p[n];
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=n-1; i>=0;i--)

    {
        p[i]=a[i];
    }
    for(i=n-1; i>=0; i--)
    {
        printf("%d",p[i]);
    }
}
