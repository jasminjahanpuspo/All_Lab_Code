#include<stdio.h>
int main()
{
    int a[5],i,even=0,odd=0;
    for(i=0; i<5; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<5; i++)
    {
        if(a[i]>0)
        {
            printf("%d",a[i]);
        }
        else if(a[i]<0){
            printf("%d",-a[i]);
        }
        else if(a[i]%2==0)
        {
            even++;
        }
        else if(a[i]%2==1)
        {
            odd++;
        }
    }
    printf("%d\n",odd);
    printf("%d",even);
}
