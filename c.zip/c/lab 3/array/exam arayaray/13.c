#include<stdio.h>
int main()
{
    int m,n;
    scanf("%d%d",&m,&n);
    int a[m][n],i,j,sum=0;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            printf("%d\t",a[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            sum=sum+a[j][i];
        }
        printf("\n%d",sum);
        sum=0;
        printf("\n");
    }
}
