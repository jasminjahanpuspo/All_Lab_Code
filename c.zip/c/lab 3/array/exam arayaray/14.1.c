#include<stdio.h>
int main()
{
    int a[2][2],b[2][2],i,j,flag=0;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++){
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++){
                scanf("%d",&b[i][j]);
           if(a[i][j]!=b[i][j])
           {
               flag=1;
               continue;
           }
        }
    }
    if(flag==0)
    {
        printf("equal");
    }
    else
        printf("not");
}
