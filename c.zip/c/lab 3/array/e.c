#include<stdio.h>
int main()
{
    int n[10],sum=0,i,a;
    printf("how many numbers?\n\n");
    scanf("%d",a);
    for(i=0; i<=9; i++)
    {
        scanf("%d",&n[i]);
    }
    for(i=0; i<=9; i++)
    {
        sum=sum+n[i];
    }
    printf("\n\nthe sum is %d\n\n",sum);
    for(i=0; i<=9; i++)
    {
        printf("address of %d\n",&n[i]);
    }
}
