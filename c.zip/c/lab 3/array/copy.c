#include<stdio.h>
int main()
{
    int a[3],i,p[3];
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<3; i++)
    {
        p[i]=a[i];
    }
    for(i=0; i<3; i++)
    {
        printf("%d\t",p[i]);
    }
}
