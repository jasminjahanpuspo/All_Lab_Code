#include<stdio.h>
int main()
{
   int n[5]={10,20,30,40,50};
   int item,loc,i;
   printf("Enter a number to search:\n\n");
   scanf("%d",&item);
   for(i=0; i<5; i++)
   {
       if(n[i]==item)
       {
           loc=i+1;
           break;
       }
   }
   if(loc==-1)
   {
       printf("not found.");
   }
   else
   {
       printf(" item found %d ",loc);
   }
}
