#include<stdio.h>
int main()
{
    int n[2],sum,i;
    for(i=0; i<2; i++)
    {
        n[i]=i+1;
        sum=n[0]+n[1];
    }
    printf("the sum is = %d\n\n",sum);
    for(i=0; i<1; i++)
    {
        printf("address of n[0] & n[1] are %d & %d \t\n",&n[i]);
    }
}
