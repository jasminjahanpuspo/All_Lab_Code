#include<stdio.h>
int main()
{
    int a[3],i,item,loc=-1;
    for(i=0; i<3; i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d",&item);
    for(i=0; i<3; i++)
    {
        if(a[i]==item)
        {
            loc=i+1;
            break;
        }
    }
    if(loc==-1)
    {
        printf("not");
    }
    else
    {
        printf("%d",loc);
    }
}
