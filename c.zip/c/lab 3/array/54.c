#include<stdio.h>
int main()
{
    int
    if(sizeof(int)>-1)
    {
        printf("hellow.");
    }
}
