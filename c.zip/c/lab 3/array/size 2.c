#include<stdio.h>
int main()
{
    int a[12]={10,20,30,40,50,60,70,80,90,100};
    int s=sizeof(a[0]);
    int f=sizeof(a);
    int e=sizeof(int);
    printf("%d\t,%d,%d",s,f,e);
}
