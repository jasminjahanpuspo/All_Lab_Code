#include<stdio.h>
int main()
{
    int m,n,a[m][n],b[m][n],i,j;
    printf("How many row ");
    scanf("%d%d",&m,&n);
    printf("First");
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&a[i][j]);
            printf("\n");
        }
    }
    printf("secon");
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&b[i][j]);
            printf("\n");
        }
    }
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            if(a[i][j]==b[i][j])
            {
                printf("equal");
                i=n++;
                break;
            }
            else
            {
                printf("not");
                i=n++;
                break;
            }
        }
    }
}
