#include<stdio.h>
int main()
{
    int i;
    for( ; ; )
    printf("Jasmin Jahan Puspo.");
}
