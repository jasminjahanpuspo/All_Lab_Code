#include<stdio.h>
int main()
{
    int m,n;
    printf("how many");
    scanf("%d%d",&m,&n);
    printf("ENT a mat");
    int a[m][n],i,j,item=0,x=0;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("\n");
    for(i=0; i<n; i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[i][j]==item)
                x++;
        }
    }
    if(x>(sizeof a[i][j]/2))
    {
        printf("mat spare");
    }
    else
    {
        printf("Not ");
    }
}
