#include<stdio.h>
int main()
{
    int a[3]={10,11,12};
    int *p;
   p=&a;
    p=&a[1];
   p=a;
    printf("%d\n",p[0]);
    printf("%d\n",p[1]);
    printf("%d\n",p[2]);
    printf("%d\n",p);


}
