#include<stdio.h>
int main()
{
    int a[3]={10,11,12};
    printf("%d\n",&a[0]);
    printf("%d\n",&a[1]);
    printf("%d\n",&a[2]);
    printf("%d\n",a);
    printf("%d\n",a+1);
    printf("%d\n",a[0]);
    printf("%d\n",*(a+0));
    printf("%d\n",a[1]);
    printf("%d\n",1[a]);
    printf("%d\n",*(a+1));
    printf("%d\n",(a+0));
    printf("%d\n",*(1+a));
}
