#include<stdio.h>
int main()
{
    int a[3]={10,11,12};
    int *p;
    p=&a[1];
    p[0]=9;
    printf("%d\n",p[0]);
    printf("%d\n",p[1]);
    printf("%d\n",p[2]);
    p++;
    //printf("%d\n",p);
    printf("%d\n",p[0]);
}
