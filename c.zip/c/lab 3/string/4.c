#include<stdio.h>
int main()
{
    int a[3]={10,11,12};
    int *p;
//    a=40;
//    &a[0]=40;
    p=a;
    p=40;
    p=&a[1];
    p=44;
    printf("%d\n",a);
    printf("%d\n",&a);
    //printf("%d\n",p);
   /*printf("%d\n",p[0]);
    printf("%d\n",p[0]);
    printf("%d\n",p[0]);*/
}
