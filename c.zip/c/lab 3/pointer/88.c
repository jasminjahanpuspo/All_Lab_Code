#include<stdio.h>
int main()
{
    int i=0xj8;
    printf("%d",i);
}
