#include<stdio.h>
int main()
{
    int *p=0;
    int *q=0;
    {
        printf("%d",*p);
    }
}
