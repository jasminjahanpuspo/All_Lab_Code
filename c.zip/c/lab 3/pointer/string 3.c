#include<stdio.h>
struct pro
{
    int id;
    float price;
    char pp[10];
};
int main()
{
    struct pro ab;
    ab.id=1;
    ab.price=40.5;
    fgets(ab.pp,10,stdin);
    struct pro cd;
    cd.id=2;
    cd.price=50.5;
    fgets(cd.pp,10,stdin);
    if(ab.price>cd.price){
    printf("id %d\tprice %f\tname ",ab.id,ab.price);
    fputs(ab.pp,stdout);
    }
    else
    {
         printf("id %d\tprice %f\tname ",cd.id,cd.price);
         fputs(cd.pp,stdout);
    }

}
