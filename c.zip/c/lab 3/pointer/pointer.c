#include<stdio.h>
struct pro
{
    int id;
    float price;
};
int main()
{
    struct pro p1;
    struct pro *p2;
    p2=&p1;
    printf("Enter id and price:\n");
    scanf("%d%f",&p1.id,&p1.price);
    printf("p1 id %d\tprice %f\n\n",p1.id,p1.price);
    printf("p2 id %d\tprice %f\n\n",p2->id,p2->price);
}
