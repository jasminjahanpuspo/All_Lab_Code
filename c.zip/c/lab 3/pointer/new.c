#include<stdio.h>
int main()
{
    int a=10,b=20,*p,*q;
    p=&a;
    *p=b;
    p=&b;
    *p=b;

    printf("%d\t%d",a,b);
}
