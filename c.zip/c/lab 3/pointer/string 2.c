#include<stdio.h>
struct pro
{
    int id;
    float price;
    char pp[10];
};
int main()
{
    struct pro p1={1,40.5,"alu"};
    printf("Id %d\tname: ",p1.id);
    fputs(p1.pp,stdout);
    printf("\tprice %f\n",p1.price);
}
