#include<stdio.h>
int main()
{
    int a=10,b=20;
    int *p;
    int *q;
    b=a;
    p=&a;
    *p=a;
    //b=a;
    a=b;
    //b=a;
    printf("%d\t%d",a,b);
}
