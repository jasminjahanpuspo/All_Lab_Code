#include<stdio.h>
int main()
{
    int a,b;
    int *p;
    p=&a;
    *p=10;
    p=&b;
    *p=20;
    printf("%d\n%d\n",a,b);
}
