#include<stdio.h>
int main()
{
    int a=10,b;
    int *p=&b;
    printf("%d",*p);
}
