#include<stdio.h>
int main()
{
    int x;
    int *a;
    a=&x;
    printf("%d\n",&a);
    printf("%d\n",*a);
    printf("%d\n",*&*a);
    printf("%d\n",&a);
    printf("%d\n",&*&*a);
}
