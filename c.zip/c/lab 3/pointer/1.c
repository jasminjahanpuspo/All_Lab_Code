#include<stdio.h>
int main()
{
    int a,b;
    int *p;
    p=&a;
    *p=10;
    printf("%d\n",*&p);
     printf("%d\n",&*p);
      printf("%d\n",*&*p);

        printf("%d\n",**&p);
         printf("%d\n",a);
          printf("%d\n",p);
           printf("%d\n",*p);
}
