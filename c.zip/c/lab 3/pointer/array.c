#include<stdio.h>
struct pro
{
    int id;
    float price;
};
int main()

{
    int i;
    struct pro a[2];
    for(i=0; i<2; i++)
    {
        printf("Enter id & price:\n");
        scanf("%d%f",&a[i].id,&a[i].price);
    }
    for(i=0; i<2; i++)
    {
        printf("product %d\tId %d\tprice %f\n",i+1,a[i].id,a[i].price);
    }

}
