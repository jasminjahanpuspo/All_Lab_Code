#include<stdio.h>
struct pro
{
    int id;
    float price;
};
int main()
{
    struct pro p1;
    struct pro p2;
    printf("Enter id & price\n");
    scanf("%d%f",&p1.id,&p1.price);
    printf("Id %d\tprice%f\n\n",p1.id,p1.price);
    printf("Enter 2nd id & price\n");
    scanf("%d%f",&p2.id,&p2.price);
    printf("Id %d\tprice%f\n\n",p2.id,p2.price);
}
