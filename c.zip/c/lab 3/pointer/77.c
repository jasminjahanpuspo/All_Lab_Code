#include<stdio.h>
int main()
{
    char ch =130;
    char ch=10;
    unsigned ch =130;
}
