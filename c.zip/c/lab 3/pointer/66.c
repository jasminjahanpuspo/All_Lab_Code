#include<stdio.h>
int main()
{
    int a=10;
    unsigned int a=10;
    unsigned int a=-10;

}
