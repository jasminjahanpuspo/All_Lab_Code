#include<stdio.h>
int main()
{
    int a,b;
    int *p=&a;
    printf("%d",a);
}
