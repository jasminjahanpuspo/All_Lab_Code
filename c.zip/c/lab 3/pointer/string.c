#include<stdio.h>
struct pro
{
    int id;
    float price;
    char pp[10];
};
int main()
{
    struct pro p1;
    scanf("%d%f",&p1.id,&p1.price);
    fgets(p1.pp,10,stdin);
    printf("Id %d\tprice %f\n",p1.id,p1.price);
   fputs(p1.pp,stdout);
}
