#include<stdio.h>
int main()
{
    float pi=3.1416L;
    printf("%f",pi);
}
