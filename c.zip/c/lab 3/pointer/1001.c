#include<stdio.h>
int main()
{
    int a=10;
    int *p=&a;
    printf("%d\n",&a);
    printf("%d\n",p);
    int *q=p;
    printf("%d\n",  q);
    printf("%d\n",p);
}
