#include<stdio.h>
int main()
{
    int a=10;
    int *p=&a;
    int *q;
    q=&p;
    printf("%d\n",*p);
    printf("%d\n",*q);
    printf("%d\n",p);
    printf("%d\n",q);
    printf("%d\n",&*q);

}
