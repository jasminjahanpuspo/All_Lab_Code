#include<stdio.h>
int main()
{
    float f=3.1416;
    float *p=&f;
    printf("%d",*p);
}
