#include<stdio.h>
int main()
{
    int n,num,temp,rev=0;
    scanf("%d",&n);
    num=n;
    while(n>0)
    {
        rev=rev*10+n%10;
        n=n/10;
    }
    if(num==rev)
    {
        printf("pallindrome.");
    }
}
