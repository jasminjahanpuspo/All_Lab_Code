#include<stdio.h>
int main()
{
    int i,n,msd,lsd;
    scanf("%d",&n);
    if(n>10)
    {


    lsd=n%10;
    printf("%d\n",lsd);
    }
    while(n>=10)
    {
        n=n/10;
    }
    msd=n;
    printf("%d",msd);
}
