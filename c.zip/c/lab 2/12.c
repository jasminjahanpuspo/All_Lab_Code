#include<stdio.h>
int main()
{
    int i,x=0,n,m,sum=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        scanf("%d",&m);
        x=x+i;
        sum=sum+x;
    }
    printf("%d",sum);
}
