#include<stdio.h>
int main()
{
    int i,a,b;
    scanf("%d%d",&a,&b);
    for(i=a; i<=b; i++)
    {
        if(i==a || i==b)
        {
            continue;
        }
        printf("%d\n",i);
    }
}
