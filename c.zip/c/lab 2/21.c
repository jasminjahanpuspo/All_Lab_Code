#include<stdio.h>
int main()
{
    int i,n,lsd,msd,sum=0;
    scanf("%d",&n);
    lsd=n%10;
   while(n>0)
    {
        sum=sum+lsd;
        n=n/10;
        lsd=n%10;
    }
    printf("%d",sum);
}
