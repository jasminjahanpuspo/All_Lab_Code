#include<stdio.h>
int main()
{
    int a,b,i;
    scanf("%d%d",&a,&b);
    for(i=0; i<a+b+1; i++)
    {
        printf("neub.\n");
    }

}
