#include<stdio.h>
int main()
{
    int n,i;
    scanf("%d",&n);
    for(i=n; n>=1; i++)
    {
        printf("%d",n);
        n--;
    }
}
