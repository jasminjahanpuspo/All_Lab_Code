#include<stdio.h>
int main()
{
    int n,i;
    scanf("%d",&n);
    for(i=0; i<=n; i++)
    {
       printf("number=%d \nsquare=%d\ncube=%d\nsrq=%.f\n\n\n",i,i*i,i*i*i,sqrt(i));
    }
}
