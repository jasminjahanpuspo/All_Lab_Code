#include<stdio.h>
int main()
{
    int i,n,m;
    float sum=0;
    scanf("%d",&n);
    for(i=0; i<=n; i++)
    {
        m=m+2;
        if(i==1)
        {
            sum=sum-1;
        }
        else if(i%2==0)

        {
            sum=sum+(m/(float)(m*m*m));
        }
        else if(i%2==1)
        {
            sum=sum-(m/(float)(m*m*m));
        }

    }
    printf("%f",sum);

}
