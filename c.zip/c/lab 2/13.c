#include<stdio.h>
int main()
{
    int i,n,m;
    float sum=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        sum=sum+((i+1)/ (float)(i*i));
    }
    printf("%f",sum);

}
