#include<stdio.h>
int main()
{
    int a,b,x,i;
    scanf("%d%d",&a,&b);
    if(a>b)
        x=a;
    else
        x=b;
    for(i=x; ;i++)
    {
        if(i%a==0 && i%b==0)
        {
            printf("%d",i);
            break;
        }
    }
}
