#include<stdio.h>
int main()
{
    int n_1=0,n_2=1,next,i;

    for(i=0; i<=1; ++i)
    {
        if(i==2)
        {
        printf("%d\t",n_1);


        next=n_1+n_2;
        n_1=n_2;
        n_2=next;
        }
    }



}
