#include<stdio.h>
int main()
{
    int i,n,m,sum=0;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        if(i%2==0)
        {
            sum=sum+0;
        }
        else if(i%2==1)
        {
            sum=sum+1;
        }
    }
    printf("%d",sum);
}
