#include<stdio.h>
int main()
{
    int i,n;
    for(i=1; i!=0; i++)
    {
        scanf("%d",&n);
        if(n>0)
        {
            printf("POSITIV\n");

        }
        else if(n<0)
        {
            printf("negative.\n");
        }
        else if(n==0)
        {
            printf("NOTHING.\n");
        }
    }
}
