#include<stdio.h>
int main()
{
    int i,base,exponent,result;
    scanf("%d%d",&base,&exponent);
    for(result=1; exponent!=0; exponent--)
    {
        result=result*base;

    }
    printf("%d",result);
}
