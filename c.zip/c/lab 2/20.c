#include<stdio.h>
int main()
{
    int i,n;
    float sum=0,m=1;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        m=m*3;
        if(i%2==1)
        {
            sum=sum+(1.0/m);
        }
        else if(i%2==0)
        {
            sum=sum-(1.0/m);
        }
    }
    printf("%.3f",sum);
}
