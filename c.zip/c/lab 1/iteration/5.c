#include<stdio.h>
int main()
{
    char ch;
    printf("alphabet in lower case letter:\n\n");
    for(ch='a'; ch<='z'; ch++)
    {
        printf("%c\t",ch);
    }
    printf("\n");
}
