#include<stdio.h>
int main()
{
    int i,n;
    for(i=0; ; i++)
    {
        printf("Enter a number:\n\n");
        scanf("%d",&n);
        if(n>0)
        {
            printf("%d is positive.\n\n",n);
        }
        else if(n<0)
        {
            printf("It is negative. \n\n");
        }
        if(n==0)
            break;
    }
}
