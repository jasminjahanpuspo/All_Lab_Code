#include<stdio.h>
int main()
{
    int i,sum=0,lsd,num;
    printf("Enter the number:\n");
    scanf("%d",&num);
    lsd=num%10;
    while(num>0)
    {
        sum=sum+lsd;
        num=num/10;
        lsd=num%10;
    }
    printf("The summation is %d",sum);
}
