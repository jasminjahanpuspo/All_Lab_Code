#include<stdio.h>
int main()
{
    int n,i,x=1,y=0;
    float sum=0;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        if(i%2==0)
        {
            if(i==0)
                sum=sum-1;
            else
                sum=sum-(y+2.0)/x;
        }
        else
        {
            sum=sum+(y+2.0)/x;
            x=x*8;
        }
    }
    printf("%f",sum);

}
