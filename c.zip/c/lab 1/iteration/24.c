#include<stdio.h>
int main()
{
    int n,num,rev=0;
    printf("Enter a number:\n");
    scanf("%d",&n);
    num=n;
    while(n!=0)
    {
        rev=(rev*10)+(n%10);
        n=n/10;
    }
    if(rev==num)
    {
        printf("%d is palindrome\n",num);
    }
    else
    {
        printf("%d is not palindrome\n",num);
    }
}
