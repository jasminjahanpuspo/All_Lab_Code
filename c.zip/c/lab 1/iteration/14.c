#include<stdio.h>
int main()
{
    int i,n;
    float sum=0,p=1;
        scanf("%d",&n);
    for(i=1; i<=n; i++)

    {
        if(i==1)
        {
            sum=sum-1;

        }
        else if(i%2==1)
        {
            p=p*2;
            sum=sum-(1/p);
        }
        else if(i%2==0)
        {
            p=p*2;
            sum=sum+(1/p);
        }
    }
    printf("%.2f",sum);
}
