#include<stdio.h>
int main()
{
    int i;
    while(i!=0)
    {
        scanf("%d",&i);
        if(i>0)
        {
            printf("Positive.");

        }
        else if(i<0)
        {
            printf("Negative.");
        }

    }
}
