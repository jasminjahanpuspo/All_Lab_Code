#include<stdio.h>
int main()
{
    int n1,n2,i;
    printf("Enter 2 numbers:\n");
    scanf("%d%d",&n1,&n2);
    for(i=0; i<=n1+n2; i++)
    {
        printf("\nneub\n");

    }
}
