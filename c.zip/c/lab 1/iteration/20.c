#include<stdio.h>
int main()
{
    int i;
    float sum=0,x=1,n;
    scanf("%f",&n);
    for(i=1; i<=n; i++)
    {
        x=x*3;
        if(i%2==1)
        {
            sum=sum+(1.0/x);
        }
        else
            sum=sum-(1.0/x);
    }
    printf("%f",sum);

}
