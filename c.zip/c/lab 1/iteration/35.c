#include<stdio.h>
int main()
{
    int i=1;
    while(i<=100000)
    {
        printf("Jasmin jahan puspo\n");
        i++;
    }
}
