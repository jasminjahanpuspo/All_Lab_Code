#include<stdio.h>
int main()
{
    int i,n;
    float sqroot;
    printf("Enter a number:\n\n");
    scanf("%d",&n);
    for(i=0; i<=0; i++)
    {
        sqroot=sqrt(n);
        printf("\nThe square is %d\n\n",n*n);
        printf("The cube is %d\n\n",n*n*n);
        printf("The squareroot is %.2f\n\n",sqroot);

    }
}
