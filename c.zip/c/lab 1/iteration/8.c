#include<stdio.h>
int main()
{
    int i,n,sum=0;
    printf("Enter an number:\n");
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        if(i%2==0)
        {
            sum=sum+i;
        }
    }
    printf("the summation of all even numbers between 1 to %d is %d",n,sum);
    printf("\n");
}
