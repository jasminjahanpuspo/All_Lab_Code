#include<stdio.h>
int main()
{
    int i,j,k=2;
    for(i=1; i<=6; i++)
    {
        for(j=0; j<1; j++)
        {
            if(i%2==1)
            {
                printf("*");
                break;
            }
        }
        for(j=0; j<k; j++)
        {
            if(i%2==0)
            {
                printf("*");
            }
        }
        if(i%2==0)
        {
            k++;

        }
        printf("\n");
    }
}
