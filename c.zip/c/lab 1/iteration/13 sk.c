#include<stdio.h>
int main()
{
    int n,i;
    float sum=0,j=1;
    scanf("%d",&n);
    for(i=2; i<n+2; i++)
    {


        sum=sum+(i/(j*j));
        j++;
    }
    printf("%.2f",sum);
}
