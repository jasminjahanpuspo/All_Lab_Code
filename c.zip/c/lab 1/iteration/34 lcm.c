#include<stdio.h>
int main()
{
    int i,m,n,x;
    printf("Enter 2 integers :\n");
    scanf("%d%d",&m,&n);
    if(m>n)
        x=m;
    else
    {
        x=n;

    }
    for(i=x; ; i++)
    {
        if(i%m==0 && i%n==0)
        {
            printf("the lcm of %d & %d is %d\n\n",m,n,i);
            break;
        }
    }
}
