#include<stdio.h>
int main()
{
    int a,b,i;
    printf("Enter 2 integer:\n");
    scanf("%d%d",&a,&b);
    printf("\nall intermideate numbers between %d to %d is \n",a,b);
    for(i=a; i<b; i++)
    {
        if(i==a || i==b)
        {
            continue;
        }
        printf("%d\t",i);
    }
    printf("\n\n");

}
