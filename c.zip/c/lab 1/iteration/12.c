#include<stdio.h>
int main()
{
    int i,n,x=0,y=0,sum=0;
    scanf("%d",&n);


    for(i=1; i<=n; i++)
    {
        x=x+1;
        y=y+x;
        sum=sum+y;
    }
    printf("%d",sum);
}
