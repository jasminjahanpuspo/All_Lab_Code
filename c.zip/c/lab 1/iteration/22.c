#include<stdio.h>
int main()
{
    int num,sum=0,msd,lsd;
    printf("Enter a number:\n");
    scanf("%d",&num);
    if(num>10)
    {
        lsd=num%10;
        printf("The lsd is %d\n\n",lsd);
    }
    while(num>=10)
    {
        num=num/10;
    }
    msd=num;
    sum=msd+lsd;
    printf("The msd is %d\n\n",msd);
    printf("The summation of msd & lsd is %d\n\n",sum);
}
