#include<stdio.h>
int main()
{
    int i;
    printf("all odd numbers from 1 to 100:\n\n");
    for(i=1; i<=100; i++)
    {
        if(i%2==1)
        {
            printf("%d\t",i);
        }
    }
}
