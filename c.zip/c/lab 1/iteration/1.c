#include<stdio.h>
int main()
{
    int n;
    printf("All natural number from 1 to n:\n\n");
    scanf("%d",&n);
    printf("\n\nIn reverse order:\n\n");
    while(n>=1)
    {
        printf("\n%d\n",n);
        n--;
    }
}
