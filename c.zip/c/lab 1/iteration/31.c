#include<stdio.h>
int main()
{
    int s,x,n=71,r=70,y=1,c;
    for(x=1; x<=7; x++)
    {
        for(s=65; s<=n;s++)
            printf("%c",s);
        if(x==2)
            r=70;
        for(c=2; c<y; c++)
            printf(" ");
        for(s=r; s>=65;s--)
            printf("%c",s);
        printf("\n");
        n--;
        r--;
        y=y+2;
    }
}
