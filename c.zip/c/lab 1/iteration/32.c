#include<stdio.h>
int main()
{
    int i,j,n=5;
    for(i=n; i>=1;i--)
    {
        for(j=n-1; j>=i; j--)
        {
            printf(" ");
        }
        printf("*");
        for(j=1; j<(i-1)*2; j++)
        {
            printf(" ");

        }
        if(i>1)
        {
            printf("*");

        }
        printf("\n");
    }
}
