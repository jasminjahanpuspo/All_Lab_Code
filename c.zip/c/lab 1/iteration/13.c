#include<stdio.h>
int main()
{
    int i,x,y=1;
    float sum,n;
    scanf("%f",&n);
    for(i=1; i<=n; i++)
    {
        y=y+1;
        x=i*i;
        sum=sum+(float)(y*1.0/x);
    }
    printf("%f",sum);
}
