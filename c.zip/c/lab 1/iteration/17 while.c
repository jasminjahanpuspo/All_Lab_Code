#include<stdio.h>
int main()
{
    int n,t1=0,t2=1,next_term=0;
    printf("Enter a number:\n");
    scanf("%d",&n);
    printf("fibonacci seris%d%d\n",t1,t2);
    next_term=t1+t2;
    while(next_term<=n)
    {
        printf("%d",next_term);
        t1=t2;
        t2=next_term;
        next_term=t1+t2;
    }
}
