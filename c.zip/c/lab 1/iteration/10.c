#include<stdio.h>
int main()
{
    int base,exponent,result=1;

    printf("Entere a base & exponent number:\n\n");
    scanf("%d%d",&base,&exponent);
    printf("\n%d to the power %d is ",base,exponent);
    while(exponent!=0)
    {
        result=result*base;
        --exponent;
    }
    printf("%d\n",result);

}
