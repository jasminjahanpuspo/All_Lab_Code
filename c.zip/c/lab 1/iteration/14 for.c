#include<stdio.h>
int main()
{
    int n,x=1,i;
    float sum=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        if(i%2!=0)
        {
            sum=sum-1.0/x;
        }
        else
        {
            sum=sum+1.0/x;
        }
        x=x*2;
    }
    printf("%f",sum);
}
