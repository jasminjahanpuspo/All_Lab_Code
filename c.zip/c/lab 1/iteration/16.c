#include<stdio.h>
int main()
{
    int i,t1=0,t2=1,next_term;

    printf("Fibonacci series:\n\n");
    for(i=1; i<=10; ++i)
    {
        printf("%d\t",t1);
        next_term=t1+t2;
        t1=t2;
        t2=next_term;
    }
}
