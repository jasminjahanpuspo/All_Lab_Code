#include<stdio.h>
int main()
{
    int a,b,compute;
    printf("enter two integer value:");
    scanf("%d%d",&a,&b);
    compute=a*a+2*a*b+b*b;
    printf("the square is= %d",compute);
}
