#include<stdio.h>
int main()
{
    int x,rev;
    printf("enter a value:");
    scanf("%d",&x);
    rev=(-1)*x;
    printf("negative number=%d",rev);
}
