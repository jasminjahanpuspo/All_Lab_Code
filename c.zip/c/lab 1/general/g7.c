#include<stdio.h>
int main()
{
    int friends,expenditure;
    float price;
    printf("enter avalue:");
    scanf("%d",&friends);
    printf("enter avalue:");
    scanf("%f",&price);
    expenditure=(friends*price);
    printf("total amount=%f",expenditure);
}
