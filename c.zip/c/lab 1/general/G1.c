#include<stdio.h>
int main()
{
    float radius,diameter;
    printf("Enter a radius of a circle:");
    scanf("%f",&radius);
    diameter=radius*2;
    printf("Diameter of a circle=%f",diameter);
}
