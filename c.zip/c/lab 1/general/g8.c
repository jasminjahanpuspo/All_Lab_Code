#include<stdio.h>
int main()
{
    int abscissa,ordinate,sum;
    float hypontenus;
    printf("enter a value:");
    scanf("%d%d",&abscissa,&ordinate);
    sum=(abscissa*abscissa)+(ordinate*ordinate);
    hypontenus=sqrt(sum);
    printf("\ntriangle hgypontenus=%f",hypontenus);
}
