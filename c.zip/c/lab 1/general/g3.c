#include<stdio.h>
int main()
{
    float x,derivative_lnx;
    printf("ent a value=");
    scanf("%f",&x);
    derivative_lnx=1/x;
    printf("derrivative(lnx)=%f",derivative_lnx);
}
