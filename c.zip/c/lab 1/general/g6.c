#include<stdio.h>
int main()
{
    int a,b,sum;
    printf("enter a value:");
    scanf("%d%d",&a,&b);
    sum=(a+b)*(a+b)*(a+b);
    printf("the compute is=%d",sum);
}
