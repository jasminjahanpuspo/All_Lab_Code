#include<stdio.h>
int main()
{
    int length,area;
    printf("Enter a length of a square:");
    scanf("%d",&length);
    area=length*length;
    printf("Area of a square=%d",area);
}
