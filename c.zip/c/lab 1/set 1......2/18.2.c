#include<stdio.h>
int main()
{
    int a,b,c,v;
    scanf("%d%d%d",&a,&b,&c);
    if(c==43)
    {
        v=a+b;
        printf("%d%d%d is %d",a,c,b,v);
    }
}
