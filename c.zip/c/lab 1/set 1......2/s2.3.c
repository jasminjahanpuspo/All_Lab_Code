#include<stdio.h>
int main()
{
    int input_seconds,temp,hours,mintues,seconds;
    printf("Enter  seconds:");
    scanf("%d",&input_seconds);
    hours=input_seconds/3600;
    temp=input_seconds%3600;
    mintues=temp/60;
    seconds=temp%60;
    printf("hours,mintues,seconds=%d%d%d",hours,mintues,seconds);
}
