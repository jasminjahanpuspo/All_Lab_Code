#include<stdio.h>
int main()
{

float u,a,t,dist;
scanf("%f%f%f",&u,&a,&t);
dist=(u*t)+(1/2.0*a*t*t);
printf("%f",dist);
}
