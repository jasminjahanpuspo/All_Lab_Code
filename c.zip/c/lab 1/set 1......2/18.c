#include<stdio.h>
int main()
{
    int a,b,value;
    char ch;
    scanf("%d%c%d",&a,&c,&b);
    if(ch=='43')
    {
        value=a+b;
        printf("%d%c%d is %d",a,ch,b,value);
    }
}
