#include<stdio.h>
int main()
{
    float feet,meter;
    printf("hh");
    scanf("%f",&feet);
    meter=feet/3.28;
    printf("hh %f",meter);
}
