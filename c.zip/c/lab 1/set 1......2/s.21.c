#include<stdio.h>
int main()
{
    float velocity,miles;
    printf("gdd");
    scanf("%f",&velocity);
    miles=velocity/88;
    printf("h %f",miles);
}
