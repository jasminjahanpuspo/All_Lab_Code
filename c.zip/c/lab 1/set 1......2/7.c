#include<stdio.h>
int main()
{
    int a,b,c,x;
    float root1,root2;
    printf("ent");
    scanf("%d%d%d",&a,&b,&c);
    x=(b*b)-(4*a*c);
    if(x<0)
    {
        printf("the is ");
    }
    else
    {
        root1=(-b+sqrt(x))/2.0*a;
        root2=(-b-sqrt(x))/2.0*a;
        printf("root%f root %f",root1,root2);
    }
}
