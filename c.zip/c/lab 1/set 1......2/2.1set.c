#include<stdio.h>
int main()
{
    int s1,s2,s3,peri;
    scanf("%d%d%d",&s1,&s2,&s3);
    peri=s1+s2+s3;
    printf("peritm %d",peri);
}
