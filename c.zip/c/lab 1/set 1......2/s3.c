#include<stdio.h>
int main()
{
    float u,a,t,distance;
    printf("ent a val");
    scanf("%f%f%f",&u,&a,&t);
    distance=u*t+1/2.0*a*t*t;
    printf("dis=%f",distance);
}
