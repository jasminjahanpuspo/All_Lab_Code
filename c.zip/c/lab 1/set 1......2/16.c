#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    if(a<=87 || a>=122)
    {
        printf("it ch");
    }
    else if(a>=48 || a<=57)
    {
        printf("it nu");
    }
    else
    {
        printf("any");
    }
}
