#include<stdio.h>
int main()
{
    float u,a,t,sujm;
    printf("ent 3 float v");
    scanf("%f%f%f",&u,&a,&t);
    sujm=(u*t)+(1/2.0)*a*t*t;
    printf("the %f",sujm);
}

