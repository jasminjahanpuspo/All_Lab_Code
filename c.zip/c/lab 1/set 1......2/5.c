#include<stdio.h>
int main()
{
    int le,be,area,peri;
    scanf("%d%d",&le,&be);
    area=le*be;
    peri=2*(le+be);
    if(area>peri)
    {
        printf("area is big");
    }
    else
    {
        printf("area is small");
    }
}
