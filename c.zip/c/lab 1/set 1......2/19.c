#include<stdio.h>
int main()
{
    int year;
    int rem,rom,kom;
    scanf("%d",&year);
    rem=year%4;
    rom=year%100;
    kom=year%400;
    if((rem==0 && rom!=0))
    {
        printf("leap %d",year);
    }
    else if(kom==0)
    {
        printf("leap%d ",year);

    }
    else
    {
        printf("%d not leap",year);
    }
}
