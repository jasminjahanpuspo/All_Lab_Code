#include<stdio.h>
int main()
{
    float dist_feet,dist_meter;
    printf("enter a dist value:");
    scanf("%f",&dist_feet);
    dist_meter=dist_feet/3.28;
    printf("the euivalent is =%f",dist_meter);
}
