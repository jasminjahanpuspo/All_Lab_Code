#include<stdio.h>
int main()
{
    int x,f,s,t,temp,sum;
    printf("h");
    scanf("%d",&x);
    t=x/100;
    temp=x%100;
    s=temp/10;
    f=s%10;
    sum=f+s+t;
    printf("h %d",sum);

}
