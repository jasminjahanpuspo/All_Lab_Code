#include<stdio.h>
 int main()
 {
     int x,f,s,t,temp,rev;
     printf("gg");
     scanf("%d",&x);
     f=x/100;
     temp=x%100;
     s=temp/10;
     t=temp%10;
     rev=t*100+s*10+f*1;
     printf("g %d",rev);
 }
