#include<stdio.h>
int main()
{
    int s1,s2,s3,perimeter;
    printf("ent a v:");
    scanf("%d%d%d",&s1,&s2,&s3);
    perimeter=s1+s2+s3;
    printf("per of a tri=%d",perimeter);
}
