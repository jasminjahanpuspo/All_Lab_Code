#include<stdio.h>
int main()
{
    int input,f,s,t,temp,rev;
    printf("ent");
    scanf("%d",&input);
    f=input/100;
    temp=input%100;
    s=temp/10;
    t=temp%10;
    rev=t*100+s*10+f*1;
    printf("hh=%d",rev);
}
