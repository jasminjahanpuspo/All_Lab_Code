#include<stdio.h>
int main()
{
    int ab,or,sum;
    float hy;
    scanf("%d%d",&ab,&or);
    sum=(ab*ab)+(or*or);
    hy=sqrt(sum);
    printf("%f",hy);
}
