#include<stdio.h>
int main()
{
    for( ; ; )
    {
        printf("a r m a n");
    }
}
