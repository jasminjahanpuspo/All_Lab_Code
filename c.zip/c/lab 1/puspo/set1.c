#include<stdio.h>
int main()
{
    float distance,inmeter ;
    printf("enter a distance value:");
    scanf("%f",&distance);
    inmeter =distance/3.28;
    printf("\ndistance in meter:%f meter",inmeter);
}
