#include<stdio.h>
int main()
{
    float radius,mul;
    printf("enter a radius:");
    scanf("%f",&radius);
    mul=radius*2*3.14;
    printf("the perimeter=%f",mul);
}
