#include<stdio.h>
int main()
{
    int ab,or,sum;
    float hy;
    printf("enter v:");
    scanf("%d%d",&ab,&or);
    sum=ab*ab+or*or;
    hy=sqrt(sum);
    printf("h=%f",hy);
}
