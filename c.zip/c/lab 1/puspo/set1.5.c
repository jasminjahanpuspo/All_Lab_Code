#include<stdio.h>
int main()
{
    int inputf,s,t,temp,rev;
    printf("enter three digit value:");
    scanf("%d",&input);
    t=input/100\n;
    temp=input%100\n;
    s=temp/10\n;
    f=temp%10\n;
    rev=f*1000+d+s*10+t*1;
    printf("the revers no:%d\n",rev);
}
