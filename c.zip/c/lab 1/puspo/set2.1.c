#include<stdio.h>
int main()
{
    float velocity,mile;
    printf("enter a value:");
    scanf("%f",&velocity);
    mile=velocity/88;
    printf("sprred=%f",mile);
}
