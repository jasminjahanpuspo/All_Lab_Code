#include<stdio.h>
int main()
{
    int x,rev;
    printf("enter a pos:");
    scanf("%d",&x);
    rev=(-1)*x;
    printf("neg=%d",rev);
}
