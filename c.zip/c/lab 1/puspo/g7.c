#include<stdio.h>
int main()
{
    int frnd,mul;
    float ice;
    printf("frnd num:");
    scanf("%d",&frnd);
    printf("ice price:");
    scanf("%f",&ice);
    mul=frnd*ice;
    printf("expen=%.f", mul);
}
