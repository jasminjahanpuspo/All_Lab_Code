#include<stdio.h>
int main()
{
    float radius,diameter;
    printf("enter radius value:");
    scanf("%f",&radius);
    diameter=radius*2;
    printf("diameter of circlr=%f",diameter);
}
