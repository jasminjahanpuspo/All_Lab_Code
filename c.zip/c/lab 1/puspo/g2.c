#include<stdio.h>
int main()
{
    int length, area;
    printf("enter a length:");
    scanf("%d",&length);
    area=length*length;
    printf("sruare=%d",area);
}
