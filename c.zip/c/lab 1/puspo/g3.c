#include<stdio.h>
int main()
{
    float x,differoflnx;
    printf("enter value:");
    scanf("%f",&x);
    differoflnx=1/x;
    printf("sum=%f",differoflnx);
}
