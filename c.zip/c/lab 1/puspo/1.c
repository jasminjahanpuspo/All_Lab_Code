#include<stdio.h>
int main()
{
    int a=10,b=20;
    int temp;
    a=temp;
    temp=b;
    printf("a=%d\nb=%d\n",a,b);
}
