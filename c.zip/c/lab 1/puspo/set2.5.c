#include<stdio.h>
int main()
{
    int input,'f','s','t',temp,sum;
    printf("enter 3 vaqlue:");
    scanf("%d"&input);
    t=input/100;
    temp=input%100;
    s=temp/10;
    f=temp%10;
    sum=t+s+f;
    printf("sum of digit:%d",sum);
}
