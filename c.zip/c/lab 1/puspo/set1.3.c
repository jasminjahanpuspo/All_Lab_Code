#include<stdio.h>
int main()
{
    float u,a,t,distance;
    printf("enter three float value:");
    scanf("%f%f%f",&u,&a,&t);
    distance=u*t+1/2.0*a*t*t;
    printf("\nthe distance of object:%f",distance);
}
