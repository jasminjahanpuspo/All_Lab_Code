#include<stdio.h>
int main()
{
    int a,b,com;
    scanf("%d%d",&a,&b);
    com=(a+b)*(a+b)*(a+b);
    printf("%d",com);
}
