#include<stdio.h>
int main()
{
    double a,b,sum;
    a=8.0;
    b=8.7;
    sum=a+b;
    printf("sum is =%lf\n",sum);
    printf("sum is =%0.2lf\n",sum);
}
