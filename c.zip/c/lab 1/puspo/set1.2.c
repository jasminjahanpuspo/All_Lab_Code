#include<stdio.h>
int main()
{
    float v1,v2,v3,sum;
    printf("enter three value of a triangle:");
    scanf("%f%f%f",&v1,&v2,&v3);
    sum=v1+v2+v3;
    printf("\n the perimeter of a triangle=%f\n",sum);
}
