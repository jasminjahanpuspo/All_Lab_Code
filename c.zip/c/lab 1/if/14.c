#include<stdio.h>
int main()
{
    float temperature_celcius;
    printf("Enter a celcius:");
    scanf("%f",&temperature_celcius);
    if(temperature_celcius>25)
    {
        printf("\nIt is warm today.");
    }
    if(temperature_celcius==25)
    {
        printf("\nIt is neutral today.");
    }
    if(temperature_celcius<25)
    {
        printf("It is freezing today.");
    }
}
