#include<stdio.h>
int main()
{
    int a,b,c,x,y;
    float root,koot;
    scanf("%d%d%d",&a,&b,&c);
    x=(b*b)-(4*a*c);
    y=sqrt(x);
    if(x<0)
    {
        printf("root ij");
    }
    else
    {
        root=(-b+y)/2.0*a;
        koot=(-b-y)/2.0*a;
        printf("h%f j%f",root,koot);
    }
}
