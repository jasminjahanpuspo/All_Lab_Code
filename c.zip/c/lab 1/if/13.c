#include<stdio.h>
int main()
{
    int x,y;
    printf("Enter an coordinate point:");
    scanf("%d%d",&x,&y);
    if(x>0&&y>0)
    {
        printf("it is first quardent\n ");
    }
    if(x<0&&y>0)  {
        printf("it is second quardent\n");
    }
    if(x<0&&y<0)
    {
        printf("it is third quardent\n");
    }
    if(x>0&&y<0)
    {
        printf("it is fourth quardent\n");
    }
}
