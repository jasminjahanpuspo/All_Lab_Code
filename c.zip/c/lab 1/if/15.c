#include<stdio.h>
int main()
{
    int day,month,year;
    printf("Enter a day,month year:\n");
    scanf("%d%d%d",&day,&month,&year);
    if(day==26 && month==03)
    {
        printf("\ntoday is independence day");
    }
    else if(day==14 && month==02)
    {
        printf("\ntoday is valentine day");
    }
    else if(day==01 && month==05)
    {
        printf("\ntoday is may day");
    }
    else
    {
        printf("\nit is regular day.");
    }
}
