#include<stdio.h>
int main()
{
    int silver_price=27075;
    int saving,zakah;
    printf("Enter saving of one year");
    scanf("%d",&saving);
    zakah=saving*(2.5/100);
    if(saving>27075)
    {
        printf("The amount is %d",zakah);
    }
}
