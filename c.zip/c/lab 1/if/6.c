#include<stdio.h>
int main()
{
    int a_c,w_b;
    scanf("%d%d",&a_c,&w_b);
    if(w_b<a_c)
        printf("error");
    else
        printf("a_c %d",a_c-w_b);

}
