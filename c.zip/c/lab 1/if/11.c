#include<stdio.h>
int main()
{
    int math,phy,che,eng,sub,marks;
    printf("Enter all subjects grade point:");
    scanf("%d%d%d%d",&math,&phy,&che,&eng);
    sub=math+phy+che+eng;
    if(sub>=17)
    {
        printf("He is eligible to admit");
    }
    else
    {
        printf("He is not eligible to admit");
    }


}
