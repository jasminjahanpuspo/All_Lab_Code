#include<stdio.h>
int main()
{
    int a,b,mul,z;
    printf("Enter 2 integers:\n ");
    scanf("%d%d",&a,&b);
    mul=a*b;
    printf("the mul is %d\n",mul);
    if(b==0)
    {
        z=0;
        printf("the result is %d\n",z);
    }
    if(b==1)
    {
        z=a;
        printf("the result is%d\n",z);
    }
    if(b==2)
    {
        z=a+a;
        printf("the result is %d\n",z);
    }
    if(b==3)
    {
        z=a+a+a;
        printf("the result is %d\n",z);
    }
    if(b==4)
    {
        z=a+a+a+a;
        printf("the result is %d\n",z);
    }
    if(b==5)
    {
        z=a+a+a+a+a;
        printf("the result is %d\n",z);
    }
    if(b==6)
    {
        z=a+a+a+a+a+a;
        printf("the result is %d\n",z);
    }
    if(b==7)
    {
        z=a+a+a+a+a+a+a;
        printf("the result is %d\n",z);
    }
    if(b==8)
    {
        z=a+a+a+a+a+a+a+a;
        printf("the result is %d\n",z);
    }
    if(b==9)
    {
        z=a+a+a+a+a+a+a+a+a;
        printf("the result is %d",z);
    }
}
