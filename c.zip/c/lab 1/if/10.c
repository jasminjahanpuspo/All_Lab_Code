#include<stdio.h>
int main()
{
    int age,distance,pay,pay2;
    printf("Enter an age and distance");
    scanf("%d%d",&age,&distance);
    if(age<=18 || age>=55)
    {
        pay=distance*2;
        printf("He need to pay%d",pay);
    }
    else
    {
        pay2=distance*5;
        printf("He neeed to pay %d",pay2);
    }
}
