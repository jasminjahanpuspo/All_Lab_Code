#include<stdio.h>
int main()
{
   char ch;
   int a;
   printf("Enter a character and number:\n");
   scanf("%c",&ch);
   scanf("%d",&a);
   if((ch>='a')&& (ch<='z')&& (ch>='A')&& (ch<='z'))
   {
       printf("It is an character.\n");
   }
   else if(a<=48 && a>=57)
   {
       printf("it is number");
   }
   else
   {
       printf("It is anything else\n.");
   }

}
