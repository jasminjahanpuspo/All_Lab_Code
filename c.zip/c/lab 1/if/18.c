#include<stdio.h>
int main()
{
    int x,y,sum,sub;

    printf("Enter an integer & an identifer:\n");
    scanf("%d%d",&x,&y);
    sum=x+y;
    printf("the sum is %d",sum);
    sub=x-y;
    printf("the sub is %d",sub);

}
