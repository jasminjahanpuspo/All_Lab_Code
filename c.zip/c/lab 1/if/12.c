#include<stdio.h>
int main()
{
    int karim,rahim,jodu,youngest;
    printf("enter three ages of brother");
    scanf("%d%d%d",&karim,&rahim,&jodu);
    if(karim<rahim)
    {
        if(karim<jodu)
        {
            printf("youngest=karim");
        }
        else
        {
            printf("youngest=jodu");
        }
    }
    else
    {
        if(rahim<jodu)
        {
            printf("youngest=rahim");
        }
        else
        {
            printf("youngest=jodu");
        }

    }
}
