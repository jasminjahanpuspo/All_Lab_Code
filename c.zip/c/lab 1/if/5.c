#include<stdio.h>
int main()


{
    int le,be,area,perimeter;

    scanf("%d%d",&le,&be);
area=le*be;
printf("area %d",area);
perimeter=2*(le+be);
printf("\nperimeter %d",perimeter);

if ( area > perimeter )
    printf("\narea is big");
}

