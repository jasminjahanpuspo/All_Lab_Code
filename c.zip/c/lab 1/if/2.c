#include<stdio.h>
int main()
{
    int sale,salary,bonus;
    printf("Enter sale &salary:");
    scanf("%d%d",&sale,&salary);
    if (sale>1000){


        bonus=salary+500;
        printf("his total salary is %d",bonus);
    }
else
{
    printf("his total salary is %d",salary);
}
}
