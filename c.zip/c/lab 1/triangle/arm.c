#include<stdio.h>
int main()
{
    int num,temp,digit_1,digit_2,digit_3;
    printf("1-500\n");
    scanf("%d",&num);

    while(num<=500)
    {
        digit_1=(num/100)-((num/1000)*10);
        digit_2=(num/10)-((num/100)*10);
        digit_3=(num-((num/10)*10));
        temp=(digit_1*digit_1*digit_1)+(digit_2*digit_2*digit_2)+(digit_3*digit_3*digit_3);
        if(temp==num)
        {
            printf("%d\n",temp);
        }
        num++;
    }
}
