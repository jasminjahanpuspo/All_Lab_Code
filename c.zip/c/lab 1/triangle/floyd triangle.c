#include<stdio.h>
int main()
{
    int i,j,x=1;
    for(i=0; i<=3;i++)
    {
        for(j=0; j<=i; j++)
        {
            printf("%d ",x);
            x++;
        }
        printf("\n");
    }
}
