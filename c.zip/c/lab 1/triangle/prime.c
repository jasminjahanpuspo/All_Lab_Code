#include<stdio.h>
int main()
{
    int i,n,prime,j;
    scanf("%d",&n);
    for(i=2; i<=n; i++)
    {
        for(j=2; j<=i/2; j++)
        {
            if(i%j==0)
            {
                prime=1;
                break;
            }
        }
        if(prime==0 && n!=1)
        {
            printf("%d",i);
        }
    }
}
