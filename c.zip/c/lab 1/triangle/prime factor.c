#include<stdio.h>
int main()
{
    int i,n,x;
    scanf("%d",&n);
    for(i=2; x>1; i++)
    {
        while(x%i==0)
        {
            printf("%d\t",i);
            x=x/i;
        }
    }
}
