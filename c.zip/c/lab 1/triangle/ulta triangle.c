#include<stdio.h>
int main()
{
    int i,j,n;
    scanf("%d",&n);
    for(i=0; i<n-i; i++)
    {
        for(j=1; j<i+1; j++)
        {
            printf(" ");
        }
        for(j=n; j>=2*i+1; j--)
        {
            printf("*");
        }
        printf("\n");

    }

}
