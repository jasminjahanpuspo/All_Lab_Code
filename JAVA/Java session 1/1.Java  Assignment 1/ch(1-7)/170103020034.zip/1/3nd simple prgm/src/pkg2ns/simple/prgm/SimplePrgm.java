package pkg2ns.simple.prgm;

public class SimplePrgm {
       public static void main(String[] args) {
        int num;
        num=100;
           System.out.println("This is num: "+num);
           num=num*2;
           System.out.print("This value of num *2 is ");
           System.out.println(num);
    }
    
}
