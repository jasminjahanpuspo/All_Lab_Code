package chardemo1;

public class Chardemo1 {    
    public static void main(String[] args) {
        char ch1, ch2;
        ch1 = 88;
        ch2 = 'y';
        System.out.print("ch1 and ch2: ");
        System.out.println(ch1 +" "+ch2);
    }
    
}
