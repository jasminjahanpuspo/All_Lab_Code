package indec;


public class Indec {   
    public static void main(String[] args) {
       int a=1,b=2,c,d;
       c=++b;
       d=a++;
       c++;
        System.out.println("a= "+a);
        System.out.println("b= "+b);
        System.out.println("c= "+c);
        System.out.println("d= "+d);
    }
    
}
