package autoarray;

public class Autoarray {    
    public static void main(String[] args) {
        int month_day[]={31,28,31,30,31,30,31,31,30,31,30,31};
       System.out.println("April has " +month_day[3] + "day");
            
        
    }
    
}
