package chardemo2;

public class Chardemo2 {

    public static void main(String[] args) {
        char ch1='x';
        System.out.println("ch1 contains "+ch1);
        ch1++;
        System.out.println("ch1 is now "+ch1);
        

    }

}
