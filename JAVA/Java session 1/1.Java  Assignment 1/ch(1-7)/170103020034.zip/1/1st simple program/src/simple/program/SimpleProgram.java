package simple.program;

public class SimpleProgram {
   public static void main(String[] args) {
        System.out.println("This is a simple Java program.");
    }
    
}
