package lab.pkg4.pkg1;

public class Lab41 {
    public static void main(String[] args) {
         String s1="Hello";
        String s2="World";
        System.out.println(s1+" "+s2);
        System.out.println("Length="+s1.length());
        System.out.println("Length="+s2.length());
       
    }    
}
