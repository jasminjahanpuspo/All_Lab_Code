package lab.pkg4.pkg2;

public class Lab42 {
    public static void main(String[] args) {
         String s1="Hello";
        String s2="World";
        System.out.println(s1+" "+s2);
        System.out.println("Length="+s1.length());
        System.out.println("Length="+s2.length());
       
        
        int a=34,b=33;
        System.out.println(a+" "+b);
        
         String ss=s1+" "+s2 + (a+b);
         System.out.println( ss );
         
    }    
}
