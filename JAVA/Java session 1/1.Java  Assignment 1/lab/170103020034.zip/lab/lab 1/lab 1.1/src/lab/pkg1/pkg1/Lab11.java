package lab.pkg1.pkg1;

public class Lab11 {
    public static void main(String[] args) {
        System.out.println("Hello world.");
    }
    
}
