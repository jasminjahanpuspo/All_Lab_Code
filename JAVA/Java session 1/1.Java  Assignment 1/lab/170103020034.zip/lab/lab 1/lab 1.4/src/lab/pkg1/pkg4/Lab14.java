package lab.pkg1.pkg4;

public class Lab14 {
    public static void main(String[] args) {        
       int fact=1,i,n=5;
       for(i=1; i<=n; i++){
           fact*=i;
       }
        System.out.println("Factorial Value="+fact);
    }
    
}
