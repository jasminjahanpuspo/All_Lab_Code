package lab.pkg1.pkg2;

public class Lab12 {
    public static void main(String[] args) {
        for(int i=0; i<100; i++){
            System.out.println("Hello World.");
        }
    }
    
}
