package lab.pkg1.pkg5;

public class Lab15 {
    public static void main(String[] args) {
        int sum=0,i,n=4;
        for(i=1; i<=n; i++)
        {
            sum+=i;
        }
        System.out.println("Sum Value="+sum);
    }
    
}
