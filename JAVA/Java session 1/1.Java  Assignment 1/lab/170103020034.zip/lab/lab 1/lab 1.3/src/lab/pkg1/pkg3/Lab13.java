package lab.pkg1.pkg3;

public class Lab13 {
    public static void main(String[] args) {
        int n=4;
        if(n%2==0)
            System.out.println("Even");
        else if(n%2==1)
            System.out.println("Odd.");
    }
    
}
